//
// https://api.twitch.tv/kraken/users/ NAME OF PROFILE /follows/channels?limit=116&offset=0
// Limit is 116, you have more than that? email me hostingmcrozz@hotmail.com about it :D
// Offset must be 0 (ZERO)
//
// Object.follows[number, from 0 to follows count].channel.name
//
//
// StatusUpdate
//
// 0 - Not updating, finished
// 1 - Timer ended, start update
// 2 - Update list of followed channels
// 3 - List of followed channels updated
// 4 - Checking online channel or not
// 5 - Error
// 6 - Name doesn't set up!
//
$.getJSON('/manifest.json', function(data){ localStorage['App_Version']=data.version });
FirstBackgroundLoad = 1;

if (FirstBackgroundLoad == 1) {
	JustAvariableRandom = 0;
	delete localStorage['NumberOfChecked'];
	while (JustAvariableRandom <= localStorage['FollowingChannels']) {
		ChangeStatus = 'Stream_Status_';
		ChangeStatus += JustAvariableRandom;
		ChangeStatus2 = 'Stream_Title_';
		ChangeStatus2 += JustAvariableRandom;
		ChangeStatus3 = 'Stream_Game_';
		ChangeStatus3 += JustAvariableRandom;
		ChangeStatus4 = 'Stream_Viewers_';
		ChangeStatus4 += JustAvariableRandom;
		ChangeStatus5 = 'Stream_Tumb_';
		ChangeStatus5 += JustAvariableRandom;
		
		localStorage[ChangeStatus] = 'Offline';
		
		delete localStorage[ChangeStatus2];
		delete localStorage[ChangeStatus3];
		delete localStorage[ChangeStatus4];
		delete localStorage[ChangeStatus5];
		
		JustAvariableRandom += 1
	};
	FirstBackgroundLoad = 0;
};

function checkStatus(url,key) {
var getJSONfile = $.getJSON(url, function(data){ statusOfStream = data })
.done(function(){ console.log('Checked '+localStorage['NumberOfChecked'].length+'/'+localStorage['FollowingChannels']) } )
.fail(function(){
	notifyUser("Update follows list", "Error, can't update","Update");
	createCookie('StatusUpdate','6',365);
	BadgeOnlineCount('0')
} );

getJSONfile.complete(function() {
	NumberOfChecked = localStorage['NumberOfChecked'];
	NumberOfChecked += '1';
	localStorage['NumberOfChecked'] = NumberOfChecked;
	
	if (statusOfStream.stream) {
		if (readCookie('NowOnline') == '0') {createCookie('NowOnline','',365)};
		NowOnline = readCookie('NowOnline');
		NowOnline += '1';
		createCookie('NowOnline',NowOnline,365);
		
		Viewers = statusOfStream.stream.viewers;
		Game = statusOfStream.stream.game;
		Status = statusOfStream.stream.channel.status;
		Name = statusOfStream.stream.channel.display_name;
		Tumb = statusOfStream.stream.preview.medium;
		Time = statusOfStream.stream.channel.updated_at;
		
		if (Status == null) {Status = 'Untitled stream'};
		if (Game == null) {Game = 'Not playing'};
			
		TitleToStorage = 'Stream_Title_';
		ViewersToStorage = 'Stream_Viewers_';
		GameToStorage = 'Stream_Game_';
		TumbToStorage = 'Stream_Tumb_';
		StatusToStorage = 'Stream_Status_';
		TimeToStorage = 'Stream_Time_'
		StatusOnline = 'Online';
		TitleToStorage += key;
		ViewersToStorage += key;
		GameToStorage += key;
		TumbToStorage += key;
		StatusToStorage += key;
		TimeToStorage += key;
			
		if (localStorage[TitleToStorage] == undefined) {
			notifyUser(Name+' just went live!',Status,'Online') 
		};
		
		if (localStorage[TitleToStorage] != Status) {
			if (localStorage[TitleToStorage] != undefined) {
				notifyUser(Name+' changed stream title on',Status,'Online') 
			}
		};
		
		localStorage[TitleToStorage] = Status;
		localStorage[ViewersToStorage] = Viewers;
		localStorage[GameToStorage] = Game;
		localStorage[TumbToStorage] = Tumb;
		localStorage[StatusToStorage] = StatusOnline;
		localStorage[TimeToStorage] = Time;
	} else {
		StatusToStorage = 'Stream_Status_';
		StatusOffline = 'Offline';			
		ViewersToStorage = 'Stream_Viewers_';
		GameToStorage = 'Stream_Game_';
		TumbToStorage = 'Stream_Tumb_';
		TitleToStorage = 'Stream_Title_';
		TimeToStorage = 'Stream_Time_'
		ViewersToStorage += key;
		GameToStorage += key;
		TumbToStorage += key;
		TitleToStorage += key;
		StatusToStorage += key;
		TimeToStorage += key;
		
		localStorage[StatusToStorage] = StatusOffline;
		
		delete localStorage[ViewersToStorage];
		delete localStorage[GameToStorage];
		delete localStorage[TumbToStorage];
		delete localStorage[TitleToStorage];
		delete localStorage[TimeToStorage];
	}
if (localStorage['NumberOfChecked'].length == localStorage['FollowingChannels']) {
		BadgeOnlineCount(readCookie('NowOnline').length);
		console.log('Checked '+localStorage['NumberOfChecked'].length+'/'+localStorage['FollowingChannels']);
		console.log('Every channel checked');
		createCookie('StatusUpdate','0',365);
		localStorage['InsertOnlineList'] = '1';
	};
});
localStorage['InsertOnlineList'] = '1';
};

function afterUpdate() {
	localStorage['NumberOfChecked'] = '';
	createCookie('NowOnline','0',365);
	NumberOfRetry = 1;
	var FollowingChannelList = [];
	FollowingChannelList.length = localStorage['FollowingChannels'];
	createCookie('StatusUpdate','4',365);
	
	$.each(FollowingChannelList, function() {
		NameToCheck = 'Stream_Name_';
		NameToCheck += NumberOfRetry;
		
		urlToCheck = 'https://api.twitch.tv/kraken/streams/'+localStorage[NameToCheck];
			
		checkStatus(urlToCheck, NumberOfRetry);
		
		NumberOfRetry += 1
	} );
};

// Checking cookies
if (!readCookie('UserName')) {localStorage['FirstLaunch'] = 'true';createCookie('UserName','Guest',365);console.error('Set up your user name in options');};
if (!readCookie('conf_Sound')) {createCookie('conf_Sound','Enable',365)};
if (!readCookie('conf_Sound_Name')) {createCookie('conf_Sound_Name','DinDon',365)};
if (!readCookie('StatusUpdate')){createCookie('StatusUpdate','6',365)};
if (!readCookie('conf_Notify')) {createCookie('conf_Notify','Enable',365)};
if (!readCookie('conf_Notify_Online')) {createCookie('conf_Notify_Online','Disable',365)};
if (!readCookie('conf_Notify_Update')) {createCookie('conf_Notify_Update','Disable',365)};
if (!readCookie('conf_StreamDuration')) {createCookie('conf_StreamDuration','Enable',365)};
//

var FirstStart = '1',
	FirstStart2 = '1';

function getCheckInsert() {
	var twitch = 'Not loaded yet!',
		statusOfStream = 'Not loaded yet!!',
		urlToJSON = 'https://api.twitch.tv/kraken/users/'+readCookie('UserName')+'/follows/channels?limit=116&offset=0';
	createCookie('StatusUpdate','1',365);
		
	if (readCookie('UserName') == 'Guest') { 
		createCookie('StatusUpdate','6',365);
		console.error('Change user name!')
	} else {
		console.log("Behold! Update is comin'");
		notifyUser('Behold! Update!','Starting update...','Update');
		createCookie('First_Notify','1',365);
		createCookie('StatusUpdate','2',365);
	
		var updateFollowingListAndCheck = $.getJSON(urlToJSON, function(data, status) {
			twitch = data;
			if (status == 'success') {
				createCookie('StatusUpdate','3',365);
				console.log('Following channels list updated, checking status')
			} else {
				console.error(status);
				createCookie('StatusUpdate','5',365)
			};
		})
		.fail(function(){
			notifyUser("Update follows list","Error, can't update","Update");
			createCookie('StatusUpdate','5',365);
			BadgeOnlineCount('0')
		} );
		
		if (updateFollowingListAndCheck.responseStatus != 200 && updateFollowingListAndCheck.responseStatus != 304 && updateFollowingListAndCheck.responseStatus != undefined && updateFollowingListAndCheck.responseStatus != 'undefined') {
			console.error("Can't update list of following channels. Status: "+updateFollowingListAndCheck.responseStatus)
			createCookie('StatusUpdate','5',365);
		};
		
		updateFollowingListAndCheck.complete(function(){
			localStorage['ChannelsCount'] = twitch._total;
			
			if (localStorage['FollowingChannels'] != twitch._total) {
				console.log('Update list of following channels');
				IndividualKeyForEachStreamer = 1;
				NumberOfRetryForKey = 0;
				localStorage['FollowingChannels'] = twitch._total;
		
				while (IndividualKeyForEachStreamer <= twitch._total) {
					NameToStorageWithKey = 'Stream_Name_';
					NameToStorageWithKey += IndividualKeyForEachStreamer;
					
					if (twitch.follows[NumberOfRetryForKey].channel.name) {
						localStorage[NameToStorageWithKey] = twitch.follows[NumberOfRetryForKey].channel.name;
						IndividualKeyForEachStreamer += 1;
						NumberOfRetryForKey += 1;
					} else {
						console.error('Get name of '+IndividualKeyForEachStreamer+' ended with error');
						NumberOfRetryForKey += 1;
					};
				};
			};
			afterUpdate();
		} );
	};
};

if (readCookie('RefreshInt')) {console.log('Refresh Interval detected: OK')}else{createCookie('RefreshInt','3',365)};

if (FirstStart == '1'){setTimeout(function(){getCheckInsert()}, 50)};

setInterval(function(){getCheckInsert()}, 1000 * 60 * readCookie('RefreshInt'));

setInterval(function(){
	if (readCookie('InstatntCheck') == '1') {
		getCheckInsert();
		createCookie('InstatntCheck','0',365)
	};
	
	if (localStorage['NumberOfChecked']) {
		if (localStorage['NumberOfChecked'].length == localStorage['FollowingChannels']) {
			if (localStorage['NumberOfChecked'] > 0) {
				if (readCookie('First_Notify') == '1') {
					if (readCookie('NowOnline').length > '1') {
						textANDchannel = 'Now online '+readCookie('NowOnline').length+' channels'
					} else if (readCookie('NowOnline').length == '1'){
						textANDchannel = 'Now online one channel'
					} else if (readCookie('NowOnline').length == '0'){
						textANDchannel = 'No one online right now :('
					}
					notifyUser('Update finished!',textANDchannel,'Update');
					createCookie('First_Notify','0',365);
				}
			}
		}
	};
	
	if (readCookie('UserName') == 'Guest') {
		JustAvariableRandom = 0;
		while (JustAvariableRandom <= localStorage['FollowingChannels']) {
			ChangeStatus = 'Stream_Status_';
			ChangeStatus += JustAvariableRandom;
			ChangeStatus2 = 'Stream_Title_';
			ChangeStatus2 += JustAvariableRandom;
			ChangeStatus3 = 'Stream_Game_';
			ChangeStatus3 += JustAvariableRandom;
			ChangeStatus4 = 'Stream_Viewers_';
			ChangeStatus4 += JustAvariableRandom;
			ChangeStatus5 = 'Stream_Tumb_';
			ChangeStatus5 += JustAvariableRandom;
			ChangeStatus6 = 'Stream_Name_';
			ChangeStatus6 += JustAvariableRandom;
			
			delete localStorage[ChangeStatus];
			delete localStorage[ChangeStatus2];
			delete localStorage[ChangeStatus3];
			delete localStorage[ChangeStatus4];
			delete localStorage[ChangeStatus5];
			delete localStorage[ChangeStatus6];
			JustAvariableRandom += 1;
			
			if (JustAvariableRandom == localStorage['FollowingChannels']) {
				delete localStorage['FollowingChannels'];
				delete localStorage['NumberOfChecked'];
				delete localStorage['NumberOfRetry'];
				delete localStorage['ChannelsCount'];
			}
		}
	}
},1000)