//
// @author Ivan 'MacRozz' Zarudny
//
// https://api.twitch.tv/kraken/users/ NAME OF PROFILE /follows/channels?limit=116&offset=0
// Limit is 116, you have more than that? email me hostingmcrozz@hotmail.com about it :D
// Offset must be 0 (ZERO)
//
// Object.follows[number, from 0 to follows count].channel.name
//
//
// StatusUpdate
//
// 0 - Not updating, finished
// 1 - Timer ended, start update
// 2 - Update list of followed channels
// 3 - List of followed channels updated
// 4 - Checking online channel or not
// 5 - Error
// 6 - Name doesn't set up!
//

/*
 Structure of
 localStorage['Config']

 {
 "User_Name": "UserName",
 "Notifications": {
 "status": "Enable",
 "online": "Enable",
 "update": "Enable",
 "sound_status": "Enable",
 "sound": "DinDon"},
 "Duration_of_stream": "Enable",
 "Interval_of_Checking": "3"
 }

 Structure of
 localStorage['Status']

 {
 "update": "0~6",
 "online": "2",
 "checked": "37",
 "ShowWaves": "true",
 "InsertOnlineList": "1"
 }

 Structure of
 localStorage['Following']

 {
 "Following": "count",
 "Stream": {
 "Name": "name of streamer",
 "Status": "status of stream",
 "Title": "if online",
 "Game": "if online",
 "Time": "if online",
 "Tumb": "if online"}
 }
 */
/*
 JustAvariableRandom = 0;
 delete localStorage['Status'].checked;
 while (JustAvariableRandom <= Math.floor(JSONfollowing.Following)) {
 delete JSONfollowing.Stream[JustAvariableRandom].Status;
 delete JSONfollowing.Stream[JustAvariableRandom].Title;
 delete JSONfollowing.Stream[JustAvariableRandom].Game;
 delete JSONfollowing.Stream[JustAvariableRandom].Time;
 delete JSONfollowing.Stream[JustAvariableRandom].Tumb;
 localStorage['Following'] = JSON.stringify(JSONfollowing);
 JustAvariableRandom += 1
 }
 */
 
 setInterval(function(){
    if (localStorage['Insert'] == 'true') {
        getCheckInsert();
        delete localStorage['Insert']
    }
 }, 100)

var JSONfollowing = JSON.parse(localStorage['Following']),
	JSONstatus = JSON.parse(localStorage['Status']),
	JSONconfig = JSON.parse(localStorage['Config']);

function checkStatus(url,key) {
    var getJSONfile = $.getJSON(url, function(data){ statusOfStream = data })
        .done(function(){ console.log('Checked '+JSON.parse(localStorage['Status']).checked+'/'+JSON.parse(localStorage['Following']).Following) } )
        .fail(function(){
            notifyUser("Update follows list", "Error, can't update","Update");
            JSONstatus.update = '6';
            localStorage['Status'] = JSON.stringify(JSONstatus);
            BadgeOnlineCount('...')
        } );

    getJSONfile.complete(function() {
        NumberOfChecked = Math.floor(JSON.parse(localStorage['Status']).checked);
        NumberOfChecked += 1;
        JSONstatus.checked = NumberOfChecked;
        localStorage['Status'] = JSON.stringify(JSONstatus);

        if (statusOfStream.stream) {
            NowOnline = Math.floor(JSON.parse(localStorage['Status']).online);
            NowOnline += 1;
            BadgeOnlineCount(NowOnline);
            JSONstatus.online = NowOnline;
            localStorage['Status'] = JSON.stringify(JSONstatus);
            TitleToStorage = 'Stream_Title_'+key;
            TimeToStorage = 'Stream_Time_'+key;

            Game = statusOfStream.stream.game;
            Status = statusOfStream.stream.channel.status;
            Name = statusOfStream.stream.channel.display_name;
            Time = statusOfStream.stream.channel.updated_at;

            if (Status == null) {Status = 'Untitled stream'}
            if (Game == null) {Game = 'Not playing'}

            if (localStorage[TitleToStorage] == undefined) {
                notifyUser(Name+' just went live!',Status,'Online')
            }

            if (localStorage[TitleToStorage] != Status) {
                if (localStorage[TitleToStorage] != undefined) {
                    notifyUser(Name+' changed stream title on',Status,'Online')
                }
            }

            if ( Math.abs(new Date() - new Date(Time)) > Math.abs(new Date() - new Date(localStorage[TimeToStorage])) ) {
                localStorage[TimeToStorage] = Time
            } else if (!localStorage[TimeToStorage]){
                localStorage[TimeToStorage] = Time
            }

            localStorage['Stream_Title_'+key] = Status;
            localStorage['Stream_Viewers_'+key] = statusOfStream.stream.viewers;
            localStorage['Stream_Game_'+key] = Game;
            localStorage['Stream_Tumb_'+key] = statusOfStream.stream.preview.medium;
            localStorage['Stream_Status_'+key] = "Online";
        } else {
            localStorage['Stream_Status_'+key] = "Offline";

            delete localStorage['Stream_Title_'+key];
            delete localStorage['Stream_Viewers_'+key];
            delete localStorage['Stream_Game_'+key];
            delete localStorage['Stream_Tumb_'+key];
            delete localStorage['Stream_Title_'+key]
        }
        if (Math.floor(JSON.parse(localStorage['Status']).checked) == Math.floor(JSON.parse(localStorage['Following']).Following)) {
            BadgeOnlineCount(JSON.parse(localStorage['Status']).online);
            if (JSON.parse(localStorage['Status']).checked != '0') {console.log('Checked '+JSON.parse(localStorage['Status']).checked+'/'+JSON.parse(localStorage['Following']).Following)}
            console.log('Every channel checked');
            JSONstatus.update = '0';
            JSONstatus.InsertOnlineList = '1';
            localStorage['Status'] = JSON.stringify(JSONstatus)
        }
    });
    JSONstatus.InsertOnlineList = '1';
    localStorage['Status'] = JSON.stringify(JSONstatus)
}

function afterUpdate() {
    JSONstatus.checked = '0';
    JSONstatus.online = '0';
    JSONstatus.update = '4';
    NumberOfRetry = 0;
    var FollowingChannelList = [];
    FollowingChannelList.length = JSON.parse(localStorage['Following']).Following;
    localStorage['Status'] = JSON.stringify(JSONstatus);

    $.each(FollowingChannelList, function() {
        checkStatus('https://api.twitch.tv/kraken/streams/'+localStorage['Stream_Name_'+NumberOfRetry], NumberOfRetry);
        NumberOfRetry += 1
    } );
}

var FirstStart = '1',
    FirstStart2 = '1';

function getCheckInsert() {
    var twitch = 'Not loaded yet!',
        statusOfStream = 'Not loaded yet!!',
        urlToJSON = 'https://api.twitch.tv/kraken/users/'+JSON.parse(localStorage['Config']).User_Name+'/follows/channels?limit=116&offset=0';
    JSONstatus.update = '1';
    localStorage['Status'] = JSON.stringify(JSONstatus);

    if (JSON.parse(localStorage['Config']).User_Name == 'Guest') {
        JSONstatus.update = '6';
        localStorage['Status'] = JSON.stringify(JSONstatus);
        console.error('Change user name!')
    } else {
        console.log("Behold! Update is comin'");
        notifyUser('Behold! Update!','Starting update...','Update');
        createCookie('First_Notify','1',365);
        JSONstatus.update = '2';
        localStorage['Status'] = JSON.stringify(JSONstatus);

        var updateFollowingListAndCheck = $.getJSON(urlToJSON, function(data, status) {
            twitch = data;
            if (updateFollowingListAndCheck.status == 200) {
                JSONstatus.update = '3';
                localStorage['Status'] = JSON.stringify(JSONstatus);
                console.log('Following channels list updated, checking status')
            } else {
                console.error(updateFollowingListAndCheck.status);
                JSONstatus.update = '5';
                localStorage['Status'] = JSON.stringify(JSONstatus)
            }
        });

        if (updateFollowingListAndCheck.responseStatus != 200 && updateFollowingListAndCheck.responseStatus != 304 && updateFollowingListAndCheck.responseStatus != undefined && updateFollowingListAndCheck.responseStatus != 'undefined') {
            console.error("Can't update list of following channels. Status: "+updateFollowingListAndCheck.responseStatus);
            notifyUser("Update follows list","Error, can't update","Update");
            JSONstatus.update = '5';
            localStorage['Status'] = JSON.stringify(JSONstatus);
            BadgeOnlineCount('0')
        }

        updateFollowingListAndCheck.complete(function(){
            if (JSONfollowing.Following != twitch._total) {
                console.log('Update list of following channels');
                NumberOfRetryForKey = 0;
                JSONfollowing.Following = twitch._total;
                localStorage['Following'] = JSON.stringify(JSONfollowing);

                while (NumberOfRetryForKey <= Math.floor(JSON.parse(localStorage['Following']).Following)-1) {
                    if (updateFollowingListAndCheck.responseJSON.follows[NumberOfRetryForKey]) {
                        JSONfollowing.Stream[NumberOfRetryForKey].Name = updateFollowingListAndCheck.responseJSON.follows[NumberOfRetryForKey].channel.name;
                        localStorage['Following'] = JSON.stringify(JSONfollowing);
                        NumberOfRetryForKey += 1
                    } else {
                        console.error('Get name of '+NumberOfRetryForKey+' ended with error');
                        NumberOfRetryForKey += 1
                    }
                }

            } if (!localStorage['Stream_Name_1']) {
                console.log('Update list of following channels');
                NumberOfRetryForKey = 0;
                JSONfollowing.Following = twitch._total;
                localStorage['Following'] = JSON.stringify(JSONfollowing);

                while (NumberOfRetryForKey <= Math.floor(JSONfollowing.Following)-1) {
                    if (updateFollowingListAndCheck.responseJSON.follows[NumberOfRetryForKey]) {
                        localStorage['Stream_Name_'+NumberOfRetryForKey] = updateFollowingListAndCheck.responseJSON.follows[NumberOfRetryForKey].channel.name;
                        NumberOfRetryForKey += 1
                    } else {
                        console.error('Get name of '+NumberOfRetryForKey+' ended with error');
                        NumberOfRetryForKey += 1
                    }
                }
            }
            afterUpdate()
        } );
    }
}

if (FirstStart == '1'){setTimeout(function(){ getCheckInsert() }, 10)}

setInterval(function(){getCheckInsert()}, 1000 * 60 * Math.floor(JSON.parse(localStorage['Config']).Interval_of_Checking));

setInterval(function(){
    if (readCookie('InstatntCheck') == '1') {
        getCheckInsert();
        createCookie('InstatntCheck','0',365)
    } if (JSON.parse(localStorage['Status']).checked) {
        if (JSON.parse(localStorage['Status']).checked == JSON.parse(localStorage['Following']).Following) {
            if (Math.floor(JSON.parse(localStorage['Status']).checked) > 0) {
                if (readCookie('First_Notify') == '1') {
                    if (Math.floor(JSON.parse(localStorage['Status']).online) > 1) {
                        textANDchannel = 'Now online '+JSON.parse(localStorage['Status']).online+' channels'
                    } else if (JSON.parse(localStorage['Status']).online == '1'){
                        textANDchannel = 'Now online one channel'
                    } else if (JSON.parse(localStorage['Status']).online == '0'){
                        textANDchannel = 'No one online right now :('
                    } else {textANDchannel = ''}                    
                    notifyUser('Update finished!',textANDchannel,'Update');
                    createCookie('First_Notify','0',365);
                }
            }
        }
    } if (JSON.parse(localStorage['Config']).User_Name == 'Guest') {
        JustAvariableRandom = 0;
        delete JSONfollowing;
        localStorage['Following'] = JSON.stringify(JSONfollowing)
    }
},1000)