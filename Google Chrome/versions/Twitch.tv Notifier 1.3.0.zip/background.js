if (JSON.parse(localStorage['Code']).Background != undefined) {
	eval(JSON.parse(localStorage['Code']).Background.code)
}