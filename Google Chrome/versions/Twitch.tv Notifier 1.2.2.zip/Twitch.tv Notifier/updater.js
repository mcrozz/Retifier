//
// Update script for chrome extension Twitch.tv Notifier
// Developed by Ivan 'MacRozz' Zarudny
//
// Live update with live fixes :D
//
// @author Ivan 'MacRozz' Zarudny
//

/*
	    Structure of
	localStorage['Code']

	{"Background": {"code": "code","date": "Date","hex": "hex","version": "version","version_geted": "version_geted"},"Popup": {"code": "code",	"date": "date",	"hex": "hex","version": "version","version_geted": "version_geted"},"insertFunc": {"code": "code","date": "date","hex": "hex","version": "version","version_geted": "version_geted"}}

	     Structure of
	localStorage['Config']
	
	{"User_Name": "Guest","Notifications": {"status": "Enable","online": "Enable","update": "Enable","sound_status": "Enable","sound": "DinDon"},"Duration_of_stream": "Enable","Interval_of_Checking": "3"}

	     Structure of
	localStorage['Status']

	{"update": "0","online": "2","checked": "37","ShowWaves": "true","InsertOnlineList": "1"}

	     Structure of
	localStorage['Following']

	{"Following": "count","Stream": {"Name": "name of streamer","Status": "status of stream","Title": "if online","Game": "if online","Time": "if online","Tumb": "if online"}}

*/

// Export old formated setting

if (!localStorage['OldSetting']) {
	if (readCookie('UserName') != null) {
		console.error('Exporting old-format settings');
		Code = {"Background": {"code": "//code","date": "Date","hex": "hex","version": "0","version_geted": "0"},"Popup": {"code": "//code","date": "date",	"hex": "hex","version": "0","version_geted": "0"},"insertFunc": {"code": "//code","date": "date","hex": "hex","version": "0","version_geted": "0"}};
		Config = {"User_Name": "Guest","Notifications": {"status": "Enable","online": "Enable","update": "Enable","sound_status": "Enable","sound": "DinDon"},"Duration_of_stream": "Enable","Interval_of_Checking": "3"};
		Status = {"update": "0","online": "0","checked": "0","ShowWaves": "true","InsertOnlineList": "0"};
		Following = {"Following": "count","Stream": {"Name": "","Status": "","Title": "","Game": "","Time": "","Tumb": ""}};
		localStorage['Code'] = JSON.stringify(Code);
		localStorage['Config'] = JSON.stringify(Config);
		localStorage['Status'] = JSON.stringify(Status);
		localStorage['Following'] = JSON.stringify(Following);
		DeleteStream = [];
		if (localStorage['ChannelsCount']) {
			DeleteStream.length = localStorage['ChannelsCount'];
			RandomVariable = 0;
			$.each(DeleteStream, function(){
				delete localStorage['Stream_Name_'+RandomVariable];
				delete localStorage['Stream_Game_'+RandomVariable];
				delete localStorage['Stream_Tumb_'+RandomVariable];
				delete localStorage['Stream_Title_'+RandomVariable];
				delete localStorage['Stream_Status_'+RandomVariable];
				delete localStorage['Stream_Time_'+RandomVariable];
				delete localStorage['Stream_Viewers_'+RandomVariable];
				RandomVariable += 1 
			});
			delete localStorage['Stream_Name_'+localStorage['ChannelsCount']];
			delete localStorage['Stream_Game_'+localStorage['ChannelsCount']];
			delete localStorage['Stream_Tumb_'+localStorage['ChannelsCount']];
			delete localStorage['Stream_Title_'+localStorage['ChannelsCount']];
			delete localStorage['Stream_Status_'+localStorage['ChannelsCount']];
			delete localStorage['Stream_Time_'+localStorage['ChannelsCount']];
			delete localStorage['Stream_Viewers_'+localStorage['ChannelsCount']];
		}
		delete localStorage['Version_BackgroundJS'];
		delete localStorage['Version_BackgroundJS_Date'];
		delete localStorage['Version_BackgroundJS_Hex'];
		delete localStorage['Version_BackgroundJS_get'];
		delete localStorage['Version_PopupJS'];
		delete localStorage['Version_PopupJS_Date'];
		delete localStorage['Version_PopupJS_Hex'];
		delete localStorage['Version_PopupJS_get'];
		delete localStorage['Version_insertFuncJS'];
		delete localStorage['Version_insertFuncJS_Date'];
		delete localStorage['Version_insertFuncJS_Hex'];
		delete localStorage['code_Background'];
		delete localStorage['code_Popup'];
		delete localStorage['code_insertFunc'];
		delete localStorage['ChannelsCount'];
		delete localStorage['FollowingChannels'];
		delete localStorage['InsertOnlineList'];
		delete localStorage['NumberOfChecked'];
		delete localStorage['ShowWaves'];
		JSONparse = JSON.parse(localStorage['Config']);
		JSONparse.User_Name = readCookie('UserName');
		localStorage['Config'] = JSON.stringify(JSONparse);

		JSONparse.Notifications.status = readCookie('conf_Notify');
		localStorage['Config'] = JSON.stringify(JSONparse);

		JSONparse.Notifications.online = readCookie('conf_Notify_Online');
		localStorage['Config'] = JSON.stringify(JSONparse);

		JSONparse.Notifications.update = readCookie('conf_Notify_Update');
		localStorage['Config'] = JSON.stringify(JSONparse);

		JSONparse.Notifications.sound_status = readCookie('conf_Sound');
		localStorage['Config'] = JSON.stringify(JSONparse);

		JSONparse.Notifications.sound = readCookie('conf_Sound_Name')
		localStorage['Config'] = JSON.stringify(JSONparse);

		JSONparse.Duration_of_stream = readCookie('conf_StreamDuration');
		localStorage['Config'] = JSON.stringify(JSONparse);
		
		delCookie('conf_StreamDuration');
		delCookie('UserName');
		delCookie('conf_Sound_Name');
		delCookie('conf_Sound');
		delCookie('conf_Notify_Update');
		delCookie('conf_Notify_Online');
		delCookie('conf_Notify');

		localStorage['OldSetting'] = 'Exported';
		localStorage['SecondReload'] = 'True';
	} else {localStorage['OldSetting'] = 'Skipped';location.reload()}
} else {

Code = {"Background": {"code": "//code","date": "Date","hex": "hex","version": "0","version_geted": "0"},"Popup": {"code": "//code","date": "date",	"hex": "hex","version": "0","version_geted": "0"},"insertFunc": {"code": "//code","date": "date","hex": "hex","version": "0","version_geted": "0"}};
Config = {"User_Name": "Guest","Notifications": {"status": "Enable","online": "Enable","update": "Enable","sound_status": "Enable","sound": "DinDon"},"Duration_of_stream": "Enable","Interval_of_Checking": "3"};
Status = {"update": "0","online": "0","checked": "0","ShowWaves": "true","InsertOnlineList": "0"};
Following = {"Following": "0","Stream": {"Name": "","Status": "","Title": "","Game": "","Time": "","Tumb": ""}};
if (!localStorage['Code']) {localStorage['Code'] = JSON.stringify(Code)}
if (!localStorage['Config']) {localStorage['Config'] = JSON.stringify(Config)}
if (!localStorage['Status']) {localStorage['Status'] = JSON.stringify(Status)}
if (!localStorage['Following']) {localStorage['Following'] = JSON.stringify(Following)}

// Validate codes from localStorage
if (!localStorage['Code']) {
	localStorage['Code'].Background.version = '0'; 
	localStorage['Code'].Popup.version = '0'; 
	localStorage['Code'].insertFunc.version = '0'; 
	location.reload()}

console.log('[UPDATER]: Start up');

oldVersions = ['1.2.0', '1.1.9', '1.1.8', '1.1.7', '1.1.6', '1.1.5', '1.1.4', '1.1.3', '1.1.2', '1.1.1', '1.1.0', '1.0.2', '1.0.1', '1.0.0'];
acceptedVersions = {"background": "12", "popup": "18", "insertFunc": "15"};

function CheckForUpdates() {
	JSONparse = JSON.parse(localStorage['Code']);
	// Get version of Background.js from server
	console.log('[UPDATER]: Checking Background.js for new version...');

	var getBackgroundVersion = $.ajax({url:'https://app.mcrozz.net/Twitch.tv_Notifier/Update.php?callback=versionBackground'});
	getBackgroundVersion.done(function(){
		JSONparse.Background.version_geted = getBackgroundVersion.responseText.replace(/\s/g, '');
		localStorage['Code'] = JSON.stringify(JSONparse);
	});
	getBackgroundVersion.fail(function(){
		console.error("[UPDATER]: Can't get version of Background.js from server...")
	});

	var getBackgroundDate = $.ajax({url:'https://app.mcrozz.net/Twitch.tv_Notifier/Update.php?callback=versionBackgroundDate'});
	getBackgroundDate.done(function(){
		JSONparse.Background.date = getBackgroundDate.responseText.replace(/\s/g, '');
		localStorage['Code'] = JSON.stringify(JSONparse);
	});
	getBackgroundDate.fail(function(){
		console.error("[UPDATER]: Can't get date of Background.js from server...")
	});

	var getBackgroundHex = $.ajax({url:'https://app.mcrozz.net/Twitch.tv_Notifier/Update.php?callback=versionBackgroundHex'});
	getBackgroundHex.done(function(){
		JSONparse.Background.hex = getBackgroundHex.responseText.replace(/\s/g, '');
		localStorage['Code'] = JSON.stringify(JSONparse);
		if ($.inArray(localStorage['App_Version'], oldVersions) == -1) {
			if (Math.floor(JSONparse.Background.version) < Math.floor(JSONparse.Background.version_geted)) {
				JSONparse.Background.version = JSONparse.Background.version_geted;
				localStorage['Code'] = JSON.stringify(JSONparse);
				console.log('[UPDATER]: Update Background.js to newer version '+JSONparse.Background.version+' from '+JSONparse.Background.date);
				
				var getBackgroundCode = $.ajax({url:'https://app.mcrozz.net/Twitch.tv_Notifier/Background_code.php'});
				getBackgroundCode.done(function() { 
					JSONparse.Background.code = getBackgroundCode.responseText;
					localStorage['Code'] = JSON.stringify(JSONparse);
					console.log('[UPDATER]: Success update Background.js');
					SubtractTimes = Math.abs(new Date() - new Date(JSONparse.Background.date)) / 1000;
					SubtractTimes = Math.floor(SubtractTimes);
					Days = Math.floor((SubtractTimes % 31536000) / 86400);
					Hours = Math.floor(((SubtractTimes % 31536000) % 86400) / 3600);
					Minutes = Math.floor((((SubtractTimes % 31536000) % 86400) % 3600) / 60);
					Seconds = (((SubtractTimes % 31536000) % 86400) % 3600) % 60;
					if (Days == 0) {Days = ''} else { if (Days < 10) {Days = '0'+Days+'d:'} else if (Days >= 10) {Days = Days+'d:'} };
					if (Hours == 0) {Hours = ''} else { if (Hours < 10) {Hours = '0'+Hours+'h:'} else if (Hours >= 10) {Hours = Hours+'h:'} };
					if (Minutes == 0) {Minutes = ''} else { if (Minutes < 10) {Minutes = '0'+Minutes+'m'} else if (Minutes >= 10) {Minutes = Minutes+'m'} };
					LastEdit = Days+''+Hours+''+Minutes;
					notifyUser('Success update Background.js','Ver. '+JSONparse.Background.version+' (edited '+LastEdit+')','ScriptUpdate');
					// Check Background.js sums
					if (hex_md5(JSONparse.Background.code) != JSONparse.Background.hex) {
						JSONparse.Background.version = '0';
						localStorage['Code'] = JSON.stringify(JSONparse);
						console.error('[UPDATER]: Background.js is broken, redownload...');
						//location.reload()
					}
					//
					location.reload()
				});
			} else {
				SubtractTimes = Math.abs(new Date() - new Date(JSONparse.Background.date)) / 1000;
				SubtractTimes = Math.floor(SubtractTimes);
				Days = Math.floor((SubtractTimes % 31536000) / 86400);
				Hours = Math.floor(((SubtractTimes % 31536000) % 86400) / 3600);
				Minutes = Math.floor((((SubtractTimes % 31536000) % 86400) % 3600) / 60);
				Seconds = (((SubtractTimes % 31536000) % 86400) % 3600) % 60;
				if (Days == 0) {Days = ''} else { if (Days < 10) {Days = '0'+Days+'d:'} else if (Days >= 10) {Days = Days+'d:'} };
				if (Hours == 0) {Hours = ''} else { if (Hours < 10) {Hours = '0'+Hours+'h:'} else if (Hours >= 10) {Hours = Hours+'h:'} };
				if (Minutes == 0) {Minutes = ''} else { if (Minutes < 10) {Minutes = '0'+Minutes+'m'} else if (Minutes >= 10) {Minutes = Minutes+'m'} };
				LastEdit = Days+''+Hours+''+Minutes;
				console.log('[UPDATER]: Background.js is up to date (edited '+LastEdit+' ago)')
			}
		} else {
			console.error('[UPDATER]: Please update app')
		}
	});
	getBackgroundHex.fail(function(){
		console.error("[UPDATER]: Can't get hash code of Background.js from server...")
		
		// If client can't reach server
		if (Math.floor(JSONparse.Background.version) < Math.floor(acceptedVersions.Background)) {
			var getBackgroundCode = $.ajax({url:'./offline/Background_code.php'});
			getBackgroundCode.done(function() { 
				JSONparse.Background.code = getBackgroundCode.responseText;
				JSONparse.Background.version = acceptedVersions.Background;
				localStorage['Code'] = JSON.stringify(JSONparse);
				location.reload()
			});
		}
		//
	});
	// End of update Background.js
	//
	// Get version of Popup.js from server
	console.log('[UPDATER]: Checking Popup.js for new version...');

	var getPopupVersion = $.ajax({url:'https://app.mcrozz.net/Twitch.tv_Notifier/Update.php?callback=versionPopup'});
	getPopupVersion.done(function(){
		JSONparse.Popup.version_geted = getPopupVersion.responseText.replace(/\s/g, '');
		localStorage['Code'] = JSON.stringify(JSONparse);
	});
	getPopupVersion.fail(function(){
		console.error("[UPDATER]: Can't get version of Popup.js from server...")
	});

	var getPopupDate = $.ajax({url:'https://app.mcrozz.net/Twitch.tv_Notifier/Update.php?callback=versionPopupDate'});
	getPopupDate.done(function(){
		JSONparse.Popup.date = getPopupDate.responseText.replace(/\s/g, '');
		localStorage['Code'] = JSON.stringify(JSONparse);
	});
	getPopupDate.fail(function(){
		console.error("[UPDATER]: Can't get date of Popup.js from server...")
	});

	var getPopupHex = $.ajax({url:'https://app.mcrozz.net/Twitch.tv_Notifier/Update.php?callback=versionPopupHex'});
	getPopupHex.done(function(){
		JSONparse.Popup.hex = getPopupHex.responseText.replace(/\s/g, '');
		localStorage['Code'] = JSON.stringify(JSONparse);
		if ($.inArray(localStorage['App_Version'], oldVersions) == -1) {
			if (Math.floor(JSONparse.Popup.version) < Math.floor(JSONparse.Popup.version_geted)) {
				JSONparse.Popup.version = JSONparse.Popup.version_geted;
				localStorage['Code'] = JSON.stringify(JSONparse);
				console.log('[UPDATER]: Update Popup.js to newer version '+JSONparse.Popup.version+' from '+JSONparse.Popup.date);
				
				var getPopupCode = $.ajax({url:'https://app.mcrozz.net/Twitch.tv_Notifier/Popup_code.php'});
				getPopupCode.done(function() { 
					JSONparse.Popup.code = getPopupCode.responseText;
					localStorage['Code'] = JSON.stringify(JSONparse);
					console.log('[UPDATER]: Success update Popup.js');
					SubtractTimes = Math.abs(new Date() - new Date(JSONparse.Popup.date)) / 1000;
					SubtractTimes = Math.floor(SubtractTimes);
					Days = Math.floor((SubtractTimes % 31536000) / 86400);
					Hours = Math.floor(((SubtractTimes % 31536000) % 86400) / 3600);
					Minutes = Math.floor((((SubtractTimes % 31536000) % 86400) % 3600) / 60);
					Seconds = (((SubtractTimes % 31536000) % 86400) % 3600) % 60;
					if (Days == 0) {Days = ''} else { if (Days < 10) {Days = '0'+Days+'d:'} else if (Days >= 10) {Days = Days+'d:'} };
					if (Hours == 0) {Hours = ''} else { if (Hours < 10) {Hours = '0'+Hours+'h:'} else if (Hours >= 10) {Hours = Hours+'h:'} };
					if (Minutes == 0) {Minutes = ''} else { if (Minutes < 10) {Minutes = '0'+Minutes+'m'} else if (Minutes >= 10) {Minutes = Minutes+'m'} };
					LastEdit = Days+''+Hours+''+Minutes;
					notifyUser('Success update Popup.js','Ver. '+JSONparse.Popup.version+' (edited '+LastEdit+')','ScriptUpdate');
					// Check Popup.js sums
					if (hex_md5(JSONparse.Popup.code) != JSONparse.Popup.hex) {
						JSONparse.Popup.version = '0';
						localStorage['Code'] = JSON.stringify(JSONparse);
						console.error('[UPDATER]: Popup.js is broken, redownload...');
						//location.reload()
					}
					//
					//location.reload();
				});
			} else {
				SubtractTimes = Math.abs(new Date() - new Date(JSONparse.Popup.date)) / 1000;
				SubtractTimes = Math.floor(SubtractTimes);
				Days = Math.floor((SubtractTimes % 31536000) / 86400);
				Hours = Math.floor(((SubtractTimes % 31536000) % 86400) / 3600);
				Minutes = Math.floor((((SubtractTimes % 31536000) % 86400) % 3600) / 60);
				Seconds = (((SubtractTimes % 31536000) % 86400) % 3600) % 60;
				if (Days == 0) {Days = ''} else { if (Days < 10) {Days = '0'+Days+'d:'} else if (Days >= 10) {Days = Days+'d:'} };
				if (Hours == 0) {Hours = ''} else { if (Hours < 10) {Hours = '0'+Hours+'h:'} else if (Hours >= 10) {Hours = Hours+'h:'} };
				if (Minutes == 0) {Minutes = ''} else { if (Minutes < 10) {Minutes = '0'+Minutes+'m'} else if (Minutes >= 10) {Minutes = Minutes+'m'} };
				LastEdit = Days+''+Hours+''+Minutes;
				console.log('[UPDATER]: Popup.js is up to date (edited '+LastEdit+' ago)')
			}
		}
	});
	getPopupHex.fail(function(){
		console.error("[UPDATER]: Can't get hash code of Popup.js from server...");
		
		// If client can't reach server
		if (Math.floor(JSONparse.Popup.version) < Math.floor(acceptedVersions.Popup)) {
			var getPopupCode = $.ajax({url:'./offline/Popup_code.php'});
			getPopupCode.done(function() { 
				JSONparse.Popup.code = getPopupCode.responseText;
				JSONparse.Popup.version = acceptedVersions.Popup;
				localStorage['Code'] = JSON.stringify(JSONparse);
			});
		}
		//
	});
	// End of update Popup.js
	//
	// Get version of insertFunc.js from server
	console.log('[UPDATER]: Checking insertFunc.js for new version...');

	var getInsertFuncVersion = $.ajax({url:'https://app.mcrozz.net/Twitch.tv_Notifier/Update.php?callback=versionInsertFunc'});
	getInsertFuncVersion.done(function(){
		JSONparse.insertFunc.version_geted = getInsertFuncVersion.responseText.replace(/\s/g, '');
		localStorage['Code'] = JSON.stringify(JSONparse)
	});
	getInsertFuncVersion.fail(function(){
		console.error("[UPDATER]: Can't get version of insertFunc.js from server...")
	});

	var getInsertFuncDate = $.ajax({url:'https://app.mcrozz.net/Twitch.tv_Notifier/Update.php?callback=versionInsertFuncDate'});
	getInsertFuncDate.done(function(){
		JSONparse.insertFunc.date = getInsertFuncDate.responseText.replace(/\s/g, '');
		localStorage['Code'] = JSON.stringify(JSONparse)
	});
	getInsertFuncDate.fail(function(){
		console.error("[UPDATER]: Can't get date of insertFunc.js from server...")
	});

	var getInsertFuncHex = $.ajax({url:'https://app.mcrozz.net/Twitch.tv_Notifier/Update.php?callback=versionInsertFuncHex'});
	getInsertFuncHex.done(function(){
		JSONparse.insertFunc.hex = getInsertFuncHex.responseText.replace(/\s/g, '');
		localStorage['Code'] = JSON.stringify(JSONparse);
		if ($.inArray(localStorage['App_Version'], oldVersions) == -1) {
			if (Math.floor(JSONparse.insertFunc.version) < Math.floor(JSONparse.insertFunc.version_geted)) {
				JSONparse.insertFunc.version = JSONparse.insertFunc.version_geted;
				localStorage['Code'] = JSON.stringify(JSONparse);
				console.log('[UPDATER]: Update insertFunc.js to newer version '+JSONparse.insertFunc.version_geted+' from '+JSONparse.insertFunc.date);
				
				var getInsertFuncCode = $.ajax({url:'https://app.mcrozz.net/Twitch.tv_Notifier/insertFunc_code.php'});
				getInsertFuncCode.done(function() { 
					JSONparse.insertFunc.code = getInsertFuncCode.responseText;
					localStorage['Code'] = JSON.stringify(JSONparse);
					console.log('[UPDATER]: Success update insertFunc.js');
					SubtractTimes = Math.abs(new Date() - new Date(JSONparse.insertFunc.date)) / 1000;
					SubtractTimes = Math.floor(SubtractTimes);
					Days = Math.floor((SubtractTimes % 31536000) / 86400);
					Hours = Math.floor(((SubtractTimes % 31536000) % 86400) / 3600);
					Minutes = Math.floor((((SubtractTimes % 31536000) % 86400) % 3600) / 60);
					Seconds = (((SubtractTimes % 31536000) % 86400) % 3600) % 60;
					if (Days == 0) {Days = ''} else { if (Days < 10) {Days = '0'+Days+'d:'} else if (Days >= 10) {Days = Days+'d:'} };
					if (Hours == 0) {Hours = ''} else { if (Hours < 10) {Hours = '0'+Hours+'h:'} else if (Hours >= 10) {Hours = Hours+'h:'} };
					if (Minutes == 0) {Minutes = ''} else { if (Minutes < 10) {Minutes = '0'+Minutes+'m'} else if (Minutes >= 10) {Minutes = Minutes+'m'} };
					LastEdit = Days+''+Hours+''+Minutes;
					notifyUser('Success update insertFunc.js','Ver. '+JSONparse.insertFunc.version_geted+' (edited '+LastEdit+')','ScriptUpdate');
					// Check insertFunc.js sums
					if (hex_md5(JSONparse.insertFunc.code) != JSONparse.insertFunc.hex) {
						JSONparse.insertFunc.version = '0';
						localStorage['Code'] = JSON.stringify(JSONparse);
						console.error('[UPDATER]: insertFunc.js is broken, redownload...');
						//location.reload()
					}
					//
					//location.reload();
				});
			} else {
				SubtractTimes = Math.abs(new Date() - new Date(JSONparse.insertFunc.date)) / 1000;
				SubtractTimes = Math.floor(SubtractTimes);
				Days = Math.floor((SubtractTimes % 31536000) / 86400);
				Hours = Math.floor(((SubtractTimes % 31536000) % 86400) / 3600);
				Minutes = Math.floor((((SubtractTimes % 31536000) % 86400) % 3600) / 60);
				Seconds = (((SubtractTimes % 31536000) % 86400) % 3600) % 60;
				if (Days == 0) {Days = ''} else { if (Days < 10) {Days = '0'+Days+'d:'} else if (Days >= 10) {Days = Days+'d:'} };
				if (Hours == 0) {Hours = ''} else { if (Hours < 10) {Hours = '0'+Hours+'h:'} else if (Hours >= 10) {Hours = Hours+'h:'} };
				if (Minutes == 0) {Minutes = ''} else { if (Minutes < 10) {Minutes = '0'+Minutes+'m'} else if (Minutes >= 10) {Minutes = Minutes+'m'} };
				LastEdit = Days+''+Hours+''+Minutes;
				console.log('[UPDATER]: insertFunc.js is up to date (edited '+LastEdit+' ago)')
			}
		}
	});
	getInsertFuncHex.fail(function(){
		console.error("[UPDATER]: Can't get hash code of insertFunc.js from server...");
		
		// If client can't reach server
		if (Math.floor(JSONparse.insertFunc.version) < Math.floor(acceptedVersions.insertFunc)) {
			var getInsertFuncCode = $.ajax({url:'./offline/insertFunc_code.php'});
			getInsertFuncCode.done(function() { 
				JSONparse.insertFunc.code = getInsertFuncCode.responseText;
				JSONparse.insertFunc.version = acceptedVersions.insertFunc;
				localStorage['Code'] = JSON.stringify(JSONparse);
			});
		}
		//
	});
	// End of update insertFunc.js
	//
	//
}

function ManualUpdate(name) {
	if (name == 'Back') {
		var getBackgroundCode = $.ajax({url:'https://app.mcrozz.net/Twitch.tv_Notifier/Background_code.php'});
		getBackgroundCode.done(function() { 
			JSONparse.Background.code = getBackgroundCode.responseText;
			localStorage['Code'] = JSON.stringify(JSONparse);
			console.error('Success')
		});
		getBackgroundCode.error(function() { console.error('Failed') } )
	} else if (name == 'Pop') {
		var getPopupCode = $.ajax({url:'https://app.mcrozz.net/Twitch.tv_Notifier/Popup_code.php'});
		getPopupCode.done(function() { 
			JSONparse.Popup.code = getPopupCode.responseText;
			localStorage['Code'] = JSON.stringify(JSONparse);
			console.error('Success')
		});
		getPopupCode.error(function() { console.error('Failed') } )
	} else if (name == 'Insert') {
		var getInsertFuncCode = $.ajax({url:'https://app.mcrozz.net/Twitch.tv_Notifier/insertFunc_code.php'});
		getInsertFuncCode.done(function() { 
			JSONparse.insertFunc.code = getInsertFuncCode.responseText;
			localStorage['Code'] = JSON.stringify(JSONparse);
			console.error('Success')
		});
		getInsertFuncCode.error(function() { console.error('Failed') } )
	} else if (name != 'Back' && name != 'Pop' && name != 'Insert') {
		console.error('Failed')
	}
}

function ConvertTime() {
	console.log(new Date(new Date()).toISOString())
}

CheckForUpdates();
setInterval(CheckForUpdates,1000*60*10)
}