//
// @author Ivan 'MacRozz' Zarudny
//
setInterval(function(){

	if (localStorage['SecondReload'] == 'True') {
		setTimeout(location.reload, 3000);
		delete localStorage['SecondReload']
	} if (Math.floor(localStorage['Reload']) <= 1) {
		localStorage['Reload'] = Math.floor(localStorage['Reload']) + 1;
		setTimeout(window.location.reload.bind(window.location), 200);
		localStorage['Insert'] = 'true'
	} else {delete localStorage['Reload']
	} if (localStorage['JustReload'] == '1') {
		delete localStorage['JustReload'];
		setTimeout(window.location.reload.bind(window.location), 200)
	}

},1000);
if (localStorage['Following'] != null && localStorage['Status'] != null && localStorage['Config'] != null) {

$.getJSON('/manifest.json', function(data){ localStorage['App_Version']=data.version });

function createCookie(name,value,days) {
	if (days) {
		var date = new Date();
		date.setTime(date.getTime()+(days*24*60*60*1000));
		expires = "; expires="+date.toGMTString();
	}
	else expires = "";
	document.cookie = name+"="+value+expires+"; path=/";
}

function readCookie(name) {
	var nameEQ = name + "=";
	var ca = document.cookie.split(';');
	for(var i=0;i < ca.length;i++) {
		var c = ca[i];
		while (c.charAt(0)==' ') c = c.substring(1,c.length);
		if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
	}
	return null;
}

function delCookie(name) {
    document.cookie = name + '=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
}

function BadgeOnlineCount(count) {
	if (count == '0') {
		chrome.browserAction.setBadgeText({text: String('')})
	} else {
		chrome.browserAction.setBadgeText({text: String(count)})
	}
}
var NotificationVar = [];

function sendNotify(Title, msg, check) {
	NotificationVar[check] = webkitNotifications.createNotification('goesOnline.png', Title, msg);
	if (check == localStorage['TempSum']) {
		console.error(new Date+' : '+Title+' -  '+msg);
		NotificationVar[check].show();
		setTimeout(function(){ NotificationVar[check].cancel() },1000 * 8);
		if (JSON.parse(localStorage['Config']).Notifications.sound_status == 'Enable') {
			Audio = document.createElement('audio');
			MusicName = '/Music/'+JSON.parse(localStorage['Config']).Notifications.sound+'.mp3';
			Audio.setAttribute('src', MusicName);
			Audio.setAttribute('autoplay', 'autoplay');
			Audio.play()
		}
	} else if (check != localStorage['TempSum']) {console.error('Security Check Notification: Denied')}
}

function notifyUser(streamerName, titleOfStream, type) {
	CheckSumKey = Math.floor(Math.random()*99);
	localStorage['TempSum'] = CheckSumKey;
	if (JSON.parse(localStorage['Config']).Notifications.status == 'Enable') {
		if (type == 'Update') {
			if (JSON.parse(localStorage['Config']).Notifications.update == 'Enable') {
				sendNotify(streamerName, titleOfStream, CheckSumKey)
			} else if (JSON.parse(localStorage['Config']).Notifications.update == 'Enable' && JSON.parse(localStorage['Config']).Notifications.status == 'Enable') {
				sendNotify(streamerName, titleOfStream, CheckSumKey)
			}
		} if (type == 'Online') {
			if (JSON.parse(localStorage['Config']).Notifications.online == 'Enable') {
				sendNotify(streamerName, titleOfStream, CheckSumKey)
			} else if (JSON.parse(localStorage['Config']).Notifications.online == 'Enable' && JSON.parse(localStorage['Config']).Notifications.status == 'Enable') {
				sendNotify(streamerName, titleOfStream, CheckSumKey)
			}
		} if (type == 'ScriptUpdate') {
			sendNotify(streamerName, titleOfStream, CheckSumKey)
		}
	}
}

function AppVersion(type, ver) {
	if (type == 'Version') {
		VersionUnit = 'ver. ';
		VersionUnit += localStorage['App_Version'];
		VersionUnit += ' (changes)';
		
		document.getElementById('AppVersionClick').innerHTML = VersionUnit
	}
}

if ( Math.floor(JSON.parse(localStorage['Code']).Background.version) < Math.floor(JSON.parse(localStorage['Code']).Background.version_geted) ) {Background = 'Out dated'} else {Background = 'New'}
if ( Math.floor(JSON.parse(localStorage['Code']).Popup.version) < Math.floor(JSON.parse(localStorage['Code']).Background.version_geted) ) {Popup = 'Out dated'} else {Popup = 'New'}
if ( Math.floor(JSON.parse(localStorage['Code']).Background.version) < Math.floor(JSON.parse(localStorage['Code']).Background.version_geted) ) {insertFunc = 'Out dated'} else {insertFunc = 'New'}


var _gaq = _gaq || [];
_gaq.push(['_setAccount', 'UA-25472862-3']);
_gaq.push(['_setCustomVar', 3, 'App_Version', localStorage['App_Version'], 1]);
_gaq.push(['_setCustomVar', 2, 'BackgroundJS', JSON.parse(localStorage['Code']).Background.version, 1]);
_gaq.push(['_setCustomVar', 2, 'PopupJS', JSON.parse(localStorage['Code']).Popup.version, 1]);
_gaq.push(['_setCustomVar', 3, 'insertFuncJS', JSON.parse(localStorage['Code']).Background.version, 1]);
_gaq.push(['_trackPageview']);
_gaq.push(['_trackEvent', 'App Version', localStorage['App_Version']]);
_gaq.push(['_trackEvent', 'BackgroundJS version', Background]);
_gaq.push(['_trackEvent', 'PopupJS version', Popup]);
_gaq.push(['_trackEvent', 'insertFuncJS version', insertFunc]);

(function() {
	var ga = document.createElement('script'); 
	ga.type = 'text/javascript'; 
	ga.async = true;
	ga.src = 'https://ssl.google-analytics.com/ga.js';
	var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
})();
}