var NumberOfidOfListOfFollowedChannels = 1,
	LinesInListOfFollowedChannels = 0;
OnlyIdOfListOfFollowedChannels = 'InsertFollowedChannelsHere';
FirstLoadVar = 1;
openCloseReportVar = 1;
openCloseVersionVar = 1;

function insertText(content,stream_id) {
	if (stream_id == 'stream_streamer') {
		document.getElementById(stream_id).href='http://www.twitch.tv/' + content;
	} else if (stream_id == 'stream_game') {
		document.getElementById(stream_id).href='http://www.twitch.tv/directory/game/' + content;
	} else if (stream_id == 'stream_img') {
		document.getElementById(stream_id).setAttribute('style', 'background:url(' + content + ')')
	} else {
		document.getElementById(stream_id).innerHTML=content
	}
};

function clickChangeUser() {
	document.getElementById("userChangePopup").setAttribute("style","display:block");
	document.getElementById("userChangePopup2").setAttribute("style","display:block");
	document.getElementById("userChangePopup").setAttribute("style","left:173");
	document.getElementById("ChgUsrNam").value=readCookie('UserName');
	document.getElementById("ChgUsrInt").value=readCookie('RefreshInt');
	changeNotify('Checking');
	checkSoundEnable('Checking')
}

function clickChangeUserCls() {
	document.getElementById("userChangePopup").setAttribute("style","display:none");
	document.getElementById("userChangePopup2").setAttribute("style","display:none");
}

function changeUserName() {
	if (document.getElementById("ChgUsrNam").value != readCookie('UserName')) {
		createCookie('InstatntCheck','1',365)
		createCookie('UserName',document.getElementById("ChgUsrNam").value,365)
	} else if (document.getElementById("ChgUsrNam").value == '') {
		createCookie('UserName','Guest',365)
	}
}

function changeReftInt() {
	if (!isNaN(document.getElementById("ChgUsrInt").value)) {
		createCookie('RefreshInt',document.getElementById("ChgUsrInt").value,365)
	}
}

function changeNotify(type) {
	if (type == 'Change') {
		if (readCookie('changed_Notify') == '1') {
			if (document.getElementById('Notify').checked) {
				createCookie('conf_Notify','Enable',365);
				createCookie('conf_Notify_Online','Disable',365);
				createCookie('conf_Notify_Update','Disable',365);
				createCookie('changed_Notify','0',365)
			} else {createCookie('changed_Notify','0',365)}
		} else if (readCookie('changed_Notify_Streamer') == '1') {
			if (document.getElementById('NotifyStreamer').checked) {
				createCookie('conf_Notify','Disable',365);
				createCookie('conf_Notify_Online','Enable',365);
				createCookie('conf_Notify_Update','Disable',365);
				createCookie('changed_Notify_Streamer','0',365)
			} else {createCookie('changed_Notify_Streamer','0',365)}
		} else if (readCookie('changed_Notify_Update') == '1') {
			if (document.getElementById('NotifyUpdate').checked) {
				createCookie('conf_Notify','Disable',365);
				createCookie('conf_Notify_Online','Disable',365);
				createCookie('conf_Notify_Update','Enable',365);
				createCookie('changed_Notify_Update','0',365)
			} else {createCookie('changed_Notify_Update','0',365)}
		}
	} else if (type == 'Checking') {
		if (readCookie('conf_Notify') == 'Enable') {
			document.getElementById('Notify').checked = true;
			document.getElementById('NotifyStreamer').checked = false;
			document.getElementById('NotifyUpdate').checked = false
		} else if (readCookie('conf_Notify_Update') == 'Enable') {
			document.getElementById('Notify').checked = false;
			document.getElementById('NotifyStreamer').checked = false;
			document.getElementById('NotifyUpdate').checked = true
		} else if (readCookie('conf_Notify_Online') == 'Enable') {
			document.getElementById('Notify').checked = false;
			document.getElementById('NotifyStreamer').checked = true;
			document.getElementById('NotifyUpdate').checked = false
		}
	}
}

function changeScriptStarter() {
	changeSoundFile('Change');
	changeUserName();
	changeReftInt();
	changeNotify('Change');
	checkSoundEnable('Change');
	clickChangeUserCls()
}

function FollowedChannelsList(content,status) {
	if (content != undefined) {
		if (LinesInListOfFollowedChannels == '19') {
			NumberOfidOfListOfFollowedChannels += 1;
		
			idOfListOfFollowedChannels = '';		
		
			idOfListOfFollowedChannels += OnlyIdOfListOfFollowedChannels;		
			idOfListOfFollowedChannels += NumberOfidOfListOfFollowedChannels;
		
			if (NumberOfidOfListOfFollowedChannels == '6') {
				LinesInListOfFollowedChannels = 0
			};
		} else {
			idOfListOfFollowedChannels = '';		
		
			idOfListOfFollowedChannels += OnlyIdOfListOfFollowedChannels;		
			idOfListOfFollowedChannels += NumberOfidOfListOfFollowedChannels
		}
	
		if (status == 'Online') {
			statusColor = 'rgb(0, 194, 40)'
		} else {
			statusColor = 'black'
		}
		
		mydiv = document.getElementById(idOfListOfFollowedChannels);
		newcontent = document.createElement('div');
		newcontent.innerHTML = '<a href="http://www.twitch.tv/'+content+'/profile" style="color:'+statusColor+';border-bottom:1px black dotted" target="_blank">'+content+'</a><br>';
	
		LinesInListOfFollowedChannels += 1;

		while (newcontent.firstChild) {
			mydiv.appendChild(newcontent.firstChild);
		}
	}
	// If 19 lines then go to next sector
	// InsertFollowedChannelsHere + Number (From 1 to 4)
}

function openFollowedList() {
	document.getElementById("firstScane").setAttribute("style","display:none");
	document.getElementById("FollowedChannelsList").setAttribute("style","display:block");

	var CountOfChannels = [];
	CountOfChannels.length = localStorage['NumberOfChecked'].length;
	CreateVarForEach = 0;
	CountOfRetryEach = 1;
	
	$.each(CountOfChannels, function() {
		StorageName = 'Stream_Name_';
		StorageName += CountOfRetryEach;
		KeyForStorageName = localStorage[StorageName];
		
		StorageStatus = 'Stream_Status_';
		StorageStatus += CountOfRetryEach;
		KeyForStorageStatus = localStorage[StorageStatus];
		
		FollowedChannelsList(KeyForStorageName,KeyForStorageStatus);
		
		CountOfRetryEach += 1;
	})
}

function closeFollowedList() {
	document.getElementById("firstScane").setAttribute("style","display:block");
	document.getElementById("FollowedChannelsList").setAttribute("style","display:none");
	insertText('','InsertFollowedChannelsHere1');
	insertText('','InsertFollowedChannelsHere2');
	insertText('','InsertFollowedChannelsHere3');
	insertText('','InsertFollowedChannelsHere4');
	insertText('','InsertFollowedChannelsHere5');
	insertText('','InsertFollowedChannelsHere6');
	NumberOfidOfListOfFollowedChannels = 1;
	LinesInListOfFollowedChannels = 0
}

function checkModifyNotify() {
	document.getElementById('NotifyStreamer').checked = false;
	document.getElementById('NotifyUpdate').checked = false;
	createCookie('changed_Notify','1',365)
}

function checkModifyNotifyStreamer() {
	document.getElementById('Notify').checked = false;
	document.getElementById('NotifyUpdate').checked = false;
	createCookie('changed_Notify_Streamer','1',365)
}

function checkModifyNotifyUpdate() {
	document.getElementById('Notify').checked = false;
	document.getElementById('NotifyStreamer').checked = false;
	createCookie('changed_Notify_Update','1',365)
}

function openCloseReportAbug() {
	if (openCloseReportVar == 1) {
		document.getElementById("FoundAbugText").setAttribute('style', 'display:block');
		document.getElementById("fndAbug").setAttribute('style', 'left:88');
		openCloseReportVar = 0
	} else if (openCloseReportVar == 0) {
		document.getElementById("FoundAbugText").setAttribute('style', 'display:none');
		document.getElementById("fndAbug").setAttribute('style', 'left:-68');
		openCloseReportVar = 1
	}
};

function checkSoundEnable(type) {
	if (type == 'Change') {
		if (document.getElementById('SoundCheck').checked == true) {
			createCookie('conf_Sound','Enable',365)
		} else if (document.getElementById('SoundCheck').checked == false) {
			createCookie('conf_Sound','Disable',365)
		}
	} else if (type == 'Checking') {
		if (readCookie('conf_Sound') == 'Enable') {
			document.getElementById('SoundCheck').checked = true
		} else if (readCookie('conf_Sound') == 'Disable') {
			document.getElementById('SoundCheck').checked = false
		}
	}
}

function openAppVersionChanges() {
	if (openCloseVersionVar == 1) {
		document.getElementById('AppChanges').setAttribute('style', 'display:block');
		changeAppContent('AppFirst');
		openCloseVersionVar = 0
	} else if (openCloseVersionVar == 0) {
		document.getElementById('AppChanges').setAttribute('style', 'display:none');
		openCloseVersionVar = 1
	}
}

function changeAppContent(App) {
	if (App == 'AppFirst') {
	
		AppFirst = '<div class="AppInfo"><a class="aAppInfo">-1.1.1 Hotfix</a></div>';
		AppFirst += '<div class="AppInfo"><a class="aAppInfo">-1.1.0 Added sound effects for notifications. Added "Version changes" page. And more...</a></div>';
		AppFirst += '<div class="AppInfo"><a class="aAppInfo">-1.0.2 Resolved a problem which freezes app</a></div>';
		AppFirst += '<div class="AppInfo"><a class="aAppInfo">-1.0.1 Bug fixes</a></div>';
		AppFirst += '<div class="AppInfo"><a class="aAppInfo">-1.0.0 First publish in Google Web Store</a></div>';
		
		document.getElementById('AppVersionContent').innerHTML = AppFirst
	} else if (App == 'AppSecond') {
	
		AppSecond = '<div class="AppInfoFuture"><a class="aAppInfoFuture">Streaming time, when streamer starts stream</a></div>';
		AppSecond = '<div class="AppInfoFuture"><a class="aAppInfoFuture">Animation</a></div>';
		
		document.getElementById('AppVersionContent').innerHTML = AppSecond
	} else if (App == 'AppThird') {
	
		AppThird = '<div class="AppInfoAbout1"><a class="aAppInfoAbout1">This extension developed and published by</a></div>';
		AppThird += "<div class='AppInfoAbout2'><a class='aAppInfoAbout2'>Ivan 'MacRozz' Zarudny</a></div>";
		AppThird += "<div class='AppInfoAbout3'><a class='aAppInfoAbout3' href='http://www.mcrozz.net' target='_blank'>My website www.mcrozz.net</a></div>";
		AppThird += "<div class='AppInfoAbout4'><a class='aAppInfoAbout4' href='http://www.twitter.com/iZarudny' target='_blank'>Twitter @iZarudny</a></div>";
		AppThird += "<div class='AppInfoAbout5'><a class='aAppInfoAbout5' href='https://chrome.google.com/webstore/detail/twitchtv-notifier/mmemeoejijknklekkdacacimmkmmokbn/reviews' target='_blank'>Don't forget to rate my app ;)</a></div>";
		
		document.getElementById('AppVersionContent').innerHTML = AppThird
	}
}

function changeSoundFile(type) {
	if (type != 'Change') {
		var Audio = document.createElement('audio');
		MusicName = '/Music/'+document.getElementById("SoundSelect").value+'.mp3';
		Audio.setAttribute('src', MusicName);
		Audio.setAttribute('autoplay', 'autoplay');
		Audio.play()
	} else if (type == 'Change'){
		createCookie('conf_Sound_Name',document.getElementById("SoundSelect").value,365)
	}
}

document.addEventListener( "DOMContentLoaded" , function () {
	document.getElementById("ChgUsr").addEventListener( "click" , clickChangeUser);
	document.getElementById("ChgUsrSnd").addEventListener( "click" , changeScriptStarter);
	document.getElementById("LstFlwdChnls").addEventListener( "click" , openFollowedList);
	document.getElementById("ClsFlwdChnlsLst").addEventListener( "click" , closeFollowedList);
	document.getElementById("Notify").addEventListener("change", checkModifyNotify);
	document.getElementById("NotifyStreamer").addEventListener("change", checkModifyNotifyStreamer);
	document.getElementById("NotifyUpdate").addEventListener("change", checkModifyNotifyUpdate);
	document.getElementById("fndAbug").addEventListener("click", openCloseReportAbug);
	document.getElementById("AppVersionClick").addEventListener("click", openAppVersionChanges);
	document.getElementById("SoundSelect").addEventListener("change", changeSoundFile);
	document.getElementById("AppFirst").addEventListener("click", function(){changeAppContent('AppFirst')});
	document.getElementById("AppSecond").addEventListener("click", function(){changeAppContent('AppSecond')});
	document.getElementById("AppThird").addEventListener("click", function(){changeAppContent('AppThird')});
	document.getElementById("AppInfoClose").addEventListener("click", function(){document.getElementById('AppChanges').setAttribute('style', 'display:none');openCloseVersionVar = 1});
	document.getElementById('userChangePopup2').addEventListener('click', function(){clickChangeUserCls()});
	document.getElementById('Dashboard').addEventListener('click', function(){window.open('http://www.twitch.tv/broadcast/dashboard')});
	document.getElementById('Direct').addEventListener('click', function(){window.open('http://www.twitch.tv/directory/following')});
} );

function insertOnlineListFunc(content,idToInsert) {
	InsertText = document.getElementById(idToInsert).innerHTML;
	InsertText += content;
	document.getElementById(idToInsert).innerHTML = InsertText;
};

function InsertOnlineList() {
	var CountOfChannels = [];
	CountOfRetryEach = 0;
	if (localStorage['NumberOfChecked']) {
		CountOfChannels.length = localStorage['NumberOfChecked'].length
	} else {
		CountOfChannels.length = null
	};
	document.getElementById('insertContentHere').innerHTML = null;
	localStorage['ShowWaves'] = 'true';
	
	
	$.each(CountOfChannels, function() {
	setTimeout(function(){
		JustAvariable = 'Stream_Status_';
		TumbURL = 'Stream_Tumb_';
		StreamTitle = 'Stream_Title_';
		StreamerName = 'Stream_Name_';
		StreamViewers = 'Stream_Viewers_';
		StreamGame = 'Stream_Game_';
		JustAvariable += CountOfRetryEach;
		TumbURL += CountOfRetryEach;
		StreamTitle += CountOfRetryEach;
		StreamerName += CountOfRetryEach;
		StreamViewers += CountOfRetryEach;
		StreamGame += CountOfRetryEach;
	
		if (localStorage[JustAvariable] == 'Online') {	
		
			StreamListUnit = '<div class="content">';
			StreamListUnit += '<div class="tumblr">';
			StreamListUnit += '<img target="_blank" id="stream_img_';
			StreamListUnit += CountOfRetryEach;
			StreamListUnit += '" height="200px" width="320px" scr=""';
			StreamListUnit += '</img>';
			StreamListUnit += '</div>';
			StreamListUnit += '<div class="information">';
			StreamListUnit += '<div class="title">';
			StreamListUnit += '<p class="pTitle">Title</p>';
			StreamListUnit += '<div class="informationTextTitle">';
			if (localStorage[StreamTitle].length >= 28) {
				lengthToCut = localStorage[StreamTitle].length;
				while (lengthToCut > 28){
					lengthToCut = lengthToCut - 1
				}
				cutStreamTitle = localStorage[StreamTitle];
				StreamListUnit += cutStreamTitle.substring (0, lengthToCut);
				StreamListUnit += '...';
			} else {
				StreamListUnit += localStorage[StreamTitle];
			};
			StreamListUnit += '</div>';
			StreamListUnit += '</div>';
			StreamListUnit += '<div class="streamer">';
			StreamListUnit += '<p class="pStreamer">Streamer</p>';
			StreamListUnit += '<a class="informationTextStreamer" target="_blank" href="http://www.twitch.tv/';
			StreamListUnit += localStorage[StreamerName];
			StreamListUnit += '">';
			StreamListUnit += localStorage[StreamerName];
			StreamListUnit += '</a>';
			StreamListUnit += '</div>';
			StreamListUnit += '<div class="viewers">';
			StreamListUnit += '<p class="pViewers">Viewers</p>';
			StreamListUnit += '<div class="informationTextViewers">';
			StreamListUnit += localStorage[StreamViewers];
			StreamListUnit += '</div>';
			StreamListUnit += '</div>';
			StreamListUnit += '<div class="gamename">';
			StreamListUnit += '<p class="pGamename">Game</p>';
			StreamListUnit += '<a class="informationTextGame" target="_blank" id="stream_game_'
			StreamListUnit += CountOfRetryEach;
			StreamListUnit += '">';
			if (localStorage[StreamGame].length >= 28) {
				lengthToCut2 = localStorage[StreamGame].length;
				while (lengthToCut2 > 28){
					lengthToCut2 = lengthToCut2 - 1
				}
				cutStreamTitle2 = localStorage[StreamGame];
				StreamListUnit += cutStreamTitle2.substring (0, lengthToCut2);
				StreamListUnit += '...';
			} else {
				StreamListUnit += localStorage[StreamGame];
			};
			StreamListUnit += '</a>';
			StreamListUnit += '</div>';
			StreamListUnit += '<div class="StreamOnChannelPage">';
			StreamListUnit += '<button type="button" name="Go to a stream page" class="button">';
			StreamListUnit += '<a href="http://www.twitch.tv/'
			StreamListUnit += localStorage[StreamerName];
			StreamListUnit += '"class="aStreamOnChannelPage" target="_blank">';
			StreamListUnit += 'Channel page';
			StreamListUnit += '</a>';
			StreamListUnit += '</button>';
			StreamListUnit += '</div>';
			StreamListUnit += '</div>';
			StreamListUnit += '</div>';
			
			if (readCookie('NowOnline') == '0') {
				localStorage['ShowWaves'] = 'true'
			} else { localStorage['ShowWaves'] = 'false' };
			
			insertOnlineListFunc(StreamListUnit,'insertContentHere');
			
			ElementIdIs = 'stream_img_';
			ElementIdIs += CountOfRetryEach;
			document.getElementById(ElementIdIs).setAttribute('style','background:url('+localStorage[TumbURL]+')');
			
			
			document.getElementById(ElementIdIs).href = 'http://www.twitch.tv/'+localStorage[StreamerName];
			
			ElementIdIs2 = 'stream_game_';
			ElementIdIs2 += CountOfRetryEach;
			document.getElementById(ElementIdIs2).href = 'http://www.twitch.tv/game/'+localStorage[StreamGame];
		};
		if (CountOfRetryEach == localStorage['NumberOfChecked'].length) {
			console.log('Insert Online List finished!')
		}
		CountOfRetryEach += 1;
	},1);
	} );
};

function progressBar(type) {
	if (type == 'Enable') {
		document.getElementById('CheckingProgress').setAttribute('style', 'display:block');
		CheckedPercent = 100 / localStorage['FollowingChannels'] * localStorage['NumberOfChecked'].length;
		document.getElementById('CheckingProgress').value = CheckedPercent
	} else if (type == 'Disable') {
		document.getElementById('CheckingProgress').setAttribute('style', 'display:none')
	}
}

document.addEventListener('DOMContentLoaded', function () {
InsertOnlineList();
AppVersion('Version');


setInterval(function(){
	if (localStorage['InsertOnlineList'] == '1') {
		InsertOnlineList();
		localStorage['InsertOnlineList'] = '0'
	}
}, 1000);

setInterval(function(){
	//
	// StatusUpdate
	//
	// 0 - Not updating, finished
	// 1 - Timer ended, start update
	// 2 - Update list of followed channels
	// 3 - List of followed channels updated
	// 4 - Checking online channel or not
	// 5 - Error
	// 6 - Name doesn't set up!
	//
	if (readCookie('StatusUpdate') == '0') {
		insertText('Now online '+readCookie('NowOnline').length+' from '+localStorage['ChannelsCount'],'FollowedChannelsOnline');
		progressBar('Disable')
	} else if (readCookie('StatusUpdate') == '1') {
		insertText('Behold! Update!','FollowedChannelsOnline')
	} else if (readCookie('StatusUpdate') == '2') { 
		insertText('Updating list of followed channels...','FollowedChannelsOnline')
	} else if (readCookie('StatusUpdate') == '3') { 
		insertText('List of followed channels updated.','FollowedChannelsOnline')
	} else if (readCookie('StatusUpdate') == '4') { 
		insertText('Now online '+readCookie('NowOnline').length+' from '+localStorage['ChannelsCount'],'FollowedChannelsOnline');
		progressBar('Enable')
	} else if (readCookie('StatusUpdate') == '5') { 
		insertText('App had a problem with update','FollowedChannelsOnline')
	} else if (readCookie('StatusUpdate') == '6') { 
		insertText("Name doesn't set up yet!",'FollowedChannelsOnline')
	};
	
	if (localStorage['ShowWaves'] == 'true') {
		document.getElementById('NoOneOnline').setAttribute('style', 'display:block')
	} else if (localStorage['ShowWaves'] == 'false') {
		document.getElementById('NoOneOnline').setAttribute('style', 'display:none')
	};
}, 100);
})


