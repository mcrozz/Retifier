_gaq.push(['_trackPageview']);

if (!readCookie('UserName')) {localStorage['FirstLaunch'] = 'true'; createCookie('UserName','Guest',365); console.error('Set up your user name in options')}
if (!readCookie('conf_Sound')) {createCookie('conf_Sound','Enable',365)}
if (!readCookie('conf_Sound_Name')) {createCookie('conf_Sound_Name','DinDon',365)}
if (!readCookie('StatusUpdate')){createCookie('StatusUpdate','6',365)}
if (!readCookie('conf_Notify')) {createCookie('conf_Notify','Enable',365)}
if (!readCookie('conf_Notify_Online')) {createCookie('conf_Notify_Online','Disable',365)}
if (!readCookie('conf_Notify_Update')) {createCookie('conf_Notify_Update','Disable',365)}
if (!readCookie('conf_StreamDuration')) {createCookie('conf_StreamDuration', 'Enable', 365)}

eval(localStorage['code_Popup'])