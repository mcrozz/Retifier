//
// Update script for chrome extension Twitch.tv Notifier
// Developed by Ivan 'MacRozz' Zarudny
//
// Live update with live fixes :D
//
// @author Ivan 'MacRozz' Zarudny
//

/*
	    Structure of
	localStorage['Code']

	{
		"Background": {
			"code": "code",
			"date": "Date",
			"hex": "hex",
			"version": "version",
			"version_geted": "version_geted"
		},
		
		"Popup": {
			"code": "code",
			"date": "date",
			"hex": "hex",
			"version": "version",
			"version_geted": "version_geted"
		},

		"insertFunc": {
			"code": "code",
			"date": "date",
			"hex": "hex",
			"version": "version",
			"version_geted": "version_geted"
		}
	}

*/

// Validate codes from localStorage
if (!localStorage['code_Background']) {localStorage['Version_BackgroundJS'] = '0'; localStorage['code_Background'] = '//Downloading Background.js...'; location.reload()};
if (!localStorage['code_Popup']) {localStorage['Version_PopupJS'] = '0'; localStorage['code_Popup'] = '//Downloading Popup.js...'; location.reload()};
if (!localStorage['code_insertFunc']) {localStorage['Version_insertFuncJS'] = '0'; localStorage['code_insertFunc'] = '//Downloading insertFunc.js...'; location.reload()};

console.log('[UPDATER]: Start up');

oldVersions = ['1.1.8', '1.1.7', '1.1.6', '1.1.5', '1.1.4', '1.1.3', '1.1.2', '1.1.1', '1.1.0', '1.0.2', '1.0.1', '1.0.0'];
acceptedVersions = {"background": "4", "popup": "15", "insertFunc": "3"};

function CheckForUpdates() {
	// Get version of Background.js from server
	console.log('[UPDATER]: Checking Background.js for new version...');

	var getBackgroundVersion = $.ajax({url:'https://app.mcrozz.net/Twitch.tv_Notifier/Update.php?callback=versionBackground'});
	getBackgroundVersion.done(function(){
		localStorage['Version_BackgroundJS_get'] = getBackgroundVersion.responseText.replace(/\s/g, '')
	});
	getBackgroundVersion.fail(function(){
		console.error("[UPDATER]: Can't get version of Background.js from server...")
	});

	var getBackgroundDate = $.ajax({url:'https://app.mcrozz.net/Twitch.tv_Notifier/Update.php?callback=versionBackgroundDate'});
	getBackgroundDate.done(function(){
		localStorage['Version_BackgroundJS_Date'] = getBackgroundDate.responseText.replace(/\s/g, '')
	});
	getBackgroundDate.fail(function(){
		console.error("[UPDATER]: Can't get date of Background.js from server...")
	});

	var getBackgroundHex = $.ajax({url:'https://app.mcrozz.net/Twitch.tv_Notifier/Update.php?callback=versionBackgroundHex'});
	getBackgroundHex.done(function(){
		localStorage['Version_BackgroundJS_Hex'] = getBackgroundHex.responseText.replace(/\s/g, '');
		if ($.inArray(localStorage['App_Version'], oldVersions) == -1) {
			if (Math.floor(localStorage['Version_BackgroundJS']) < Math.floor(localStorage['Version_BackgroundJS_get'])) {
				localStorage['Version_BackgroundJS'] = localStorage['Version_BackgroundJS_get'];
				console.log('[UPDATER]: Update Background.js to newer version '+localStorage['Version_BackgroundJS']+' from '+localStorage['Version_BackgroundJS_Date']);
				
				var getBackgroundCode = $.ajax({url:'https://app.mcrozz.net/Twitch.tv_Notifier/Background_code.php'});
				getBackgroundCode.done(function() { 
					localStorage['code_Background'] = getBackgroundCode.responseText;
					console.log('[UPDATER]: Success update Background.js');
					SubtractTimes = Math.abs(new Date() - new Date(localStorage['Version_BackgroundJS_Date'])) / 1000;
					SubtractTimes = Math.floor(SubtractTimes);
					Days = Math.floor((SubtractTimes % 31536000) / 86400);
					Hours = Math.floor(((SubtractTimes % 31536000) % 86400) / 3600);
					Minutes = Math.floor((((SubtractTimes % 31536000) % 86400) % 3600) / 60);
					Seconds = (((SubtractTimes % 31536000) % 86400) % 3600) % 60;
					if (Days == 0) {Days = ''} else { if (Days < 10) {Days = '0'+Days+'d:'} else if (Days >= 10) {Days = Days+'d:'} };
					if (Hours == 0) {Hours = ''} else { if (Hours < 10) {Hours = '0'+Hours+'h:'} else if (Hours >= 10) {Hours = Hours+'h:'} };
					if (Minutes == 0) {Minutes = ''} else { if (Minutes < 10) {Minutes = '0'+Minutes+'m:'} else if (Minutes >= 10) {Minutes = Minutes+'m'} };
					LastEdit = Days+''+Hours+''+Minutes;
					notifyUser('Success update Background.js','Ver. '+localStorage['Version_BackgroundJS']+' (edited '+LastEdit+')','ScriptUpdate');
					// Check Background.js sums
					if (hex_md5(localStorage['code_Background']) != localStorage['Version_BackgroundJS_Hex']) {
						localStorage['Version_BackgroundJS'] = '0';
						console.error('[UPDATER]: Background.js is broken, redownload...');
						//location.reload()
					}
					//
					location.reload();
				});
			} else {
				SubtractTimes = Math.abs(new Date() - new Date(localStorage['Version_BackgroundJS_Date'])) / 1000;
				SubtractTimes = Math.floor(SubtractTimes);
				Days = Math.floor((SubtractTimes % 31536000) / 86400);
				Hours = Math.floor(((SubtractTimes % 31536000) % 86400) / 3600);
				Minutes = Math.floor((((SubtractTimes % 31536000) % 86400) % 3600) / 60);
				Seconds = (((SubtractTimes % 31536000) % 86400) % 3600) % 60;
				if (Days == 0) {Days = ''} else { if (Days < 10) {Days = '0'+Days+'d:'} else if (Days >= 10) {Days = Days+'d:'} };
				if (Hours == 0) {Hours = ''} else { if (Hours < 10) {Hours = '0'+Hours+'h:'} else if (Hours >= 10) {Hours = Hours+'h:'} };
				if (Minutes == 0) {Minutes = ''} else { if (Minutes < 10) {Minutes = '0'+Minutes+'m:'} else if (Minutes >= 10) {Minutes = Minutes+'m'} };
				LastEdit = Days+''+Hours+''+Minutes;
				console.log('[UPDATER]: Background.js is up to date (edited '+LastEdit+' ago)')
			}
		} else {
			console.error('[UPDATER]: Please update app')
		}
	});
	getBackgroundHex.fail(function(){
		console.error("[UPDATER]: Can't get hash code of Background.js from server...")
		
		// If client can't reach server
		if (Math.floor(localStorage['Version_BackgroundJS']) < Math.floor(acceptedVersions.Background)) {
			var getBackgroundCode = $.ajax({url:'./offline/Background_code.php'});
			getBackgroundCode.done(function() { 
				localStorage['code_Background'] = getBackgroundCode.responseText;
				localStorage['Version_BackgroundJS'] = acceptedVersions.Background;
				location.reload()
			});
		}
		//
	});
	// End of update Background.js
	//
	// Get version of Popup.js from server
	console.log('[UPDATER]: Checking Popup.js for new version...');

	var getPopupVersion = $.ajax({url:'https://app.mcrozz.net/Twitch.tv_Notifier/Update.php?callback=versionPopup'});
	getPopupVersion.done(function(){
		localStorage['Version_PopupJS_get'] = getPopupVersion.responseText.replace(/\s/g, '')
	});
	getPopupVersion.fail(function(){
		console.error("[UPDATER]: Can't get version of Popup.js from server...")
	});

	var getPopupDate = $.ajax({url:'https://app.mcrozz.net/Twitch.tv_Notifier/Update.php?callback=versionPopupDate'});
	getPopupDate.done(function(){
		localStorage['Version_PopupJS_Date'] = getPopupDate.responseText.replace(/\s/g, '')
	});
	getPopupDate.fail(function(){
		console.error("[UPDATER]: Can't get date of Popup.js from server...")
	});

	var getPopupHex = $.ajax({url:'https://app.mcrozz.net/Twitch.tv_Notifier/Update.php?callback=versionPopupHex'});
	getPopupHex.done(function(){
		localStorage['Version_PopupJS_Hex'] = getPopupHex.responseText.replace(/\s/g, '');
		if ($.inArray(localStorage['App_Version'], oldVersions) == -1) {
			if (Math.floor(localStorage['Version_PopupJS']) < Math.floor(localStorage['Version_PopupJS_get'])) {
				localStorage['Version_PopupJS'] = localStorage['Version_PopupJS_get'];
				console.log('[UPDATER]: Update Popup.js to newer version '+localStorage['Version_PopupJS']+' from '+localStorage['Version_PopupJS_Date']);
				
				var getPopupCode = $.ajax({url:'https://app.mcrozz.net/Twitch.tv_Notifier/Popup_code.php'});
				getPopupCode.done(function() { 
					localStorage['code_Popup'] = getPopupCode.responseText;
					console.log('[UPDATER]: Success update Popup.js');
					SubtractTimes = Math.abs(new Date() - new Date(localStorage['Version_PopupJS_Date'])) / 1000;
					SubtractTimes = Math.floor(SubtractTimes);
					Days = Math.floor((SubtractTimes % 31536000) / 86400);
					Hours = Math.floor(((SubtractTimes % 31536000) % 86400) / 3600);
					Minutes = Math.floor((((SubtractTimes % 31536000) % 86400) % 3600) / 60);
					Seconds = (((SubtractTimes % 31536000) % 86400) % 3600) % 60;
					if (Days == 0) {Days = ''} else { if (Days < 10) {Days = '0'+Days+'d:'} else if (Days >= 10) {Days = Days+'d:'} };
					if (Hours == 0) {Hours = ''} else { if (Hours < 10) {Hours = '0'+Hours+'h:'} else if (Hours >= 10) {Hours = Hours+'h:'} };
					if (Minutes == 0) {Minutes = ''} else { if (Minutes < 10) {Minutes = '0'+Minutes+'m:'} else if (Minutes >= 10) {Minutes = Minutes+'m'} };
					LastEdit = Days+''+Hours+''+Minutes;
					notifyUser('Success update Popup.js','Ver. '+localStorage['Version_PopupJS']+' (edited '+LastEdit+')','ScriptUpdate');
					// Check Popup.js sums
					if (hex_md5(localStorage['code_Popup']) != localStorage['Version_PopupJS_Hex']) {
						localStorage['Version_PopupJS'] = '0';
						console.error('[UPDATER]: Popup.js is broken, redownload...');
						//location.reload()
					}
					//
					//location.reload();
				});
			} else {
				SubtractTimes = Math.abs(new Date() - new Date(localStorage['Version_PopupJS_Date'])) / 1000;
				SubtractTimes = Math.floor(SubtractTimes);
				Days = Math.floor((SubtractTimes % 31536000) / 86400);
				Hours = Math.floor(((SubtractTimes % 31536000) % 86400) / 3600);
				Minutes = Math.floor((((SubtractTimes % 31536000) % 86400) % 3600) / 60);
				Seconds = (((SubtractTimes % 31536000) % 86400) % 3600) % 60;
				if (Days == 0) {Days = ''} else { if (Days < 10) {Days = '0'+Days+'d:'} else if (Days >= 10) {Days = Days+'d:'} };
				if (Hours == 0) {Hours = ''} else { if (Hours < 10) {Hours = '0'+Hours+'h:'} else if (Hours >= 10) {Hours = Hours+'h:'} };
				if (Minutes == 0) {Minutes = ''} else { if (Minutes < 10) {Minutes = '0'+Minutes+'m:'} else if (Minutes >= 10) {Minutes = Minutes+'m'} };
				LastEdit = Days+''+Hours+''+Minutes;
				console.log('[UPDATER]: Popup.js is up to date (edited '+LastEdit+' ago)')
			}
		}
	});
	getPopupHex.fail(function(){
		console.error("[UPDATER]: Can't get hash code of Popup.js from server...");
		
		// If client can't reach server
		if (Math.floor(localStorage['Version_PopupJS']) < Math.floor(acceptedVersions.Popup)) {
			var getPopupCode = $.ajax({url:'./offline/Popup_code.php'});
			getPopupCode.done(function() { 
				localStorage['code_Popup'] = getPopupCode.responseText;
				localStorage['Version_PopupJS'] = acceptedVersions.Popup;
			});
		}
		//
	});
	// End of update Popup.js
	//
	// Get version of insertFunc.js from server
	console.log('[UPDATER]: Checking insertFunc.js for new version...');

	var getInsertFuncVersion = $.ajax({url:'https://app.mcrozz.net/Twitch.tv_Notifier/Update.php?callback=versionInsertFunc'});
	getInsertFuncVersion.done(function(){
		localStorage['Version_insertFuncJS_get'] = getInsertFuncVersion.responseText.replace(/\s/g, '')
	});
	getInsertFuncVersion.fail(function(){
		console.error("[UPDATER]: Can't get version of insertFunc.js from server...")
	});

	var getInsertFuncDate = $.ajax({url:'https://app.mcrozz.net/Twitch.tv_Notifier/Update.php?callback=versionInsertFuncDate'});
	getInsertFuncDate.done(function(){
		localStorage['Version_insertFuncJS_Date'] = getInsertFuncDate.responseText.replace(/\s/g, '')
	});
	getInsertFuncDate.fail(function(){
		console.error("[UPDATER]: Can't get date of insertFunc.js from server...")
	});

	var getInsertFuncHex = $.ajax({url:'https://app.mcrozz.net/Twitch.tv_Notifier/Update.php?callback=versionInsertFuncHex'});
	getInsertFuncHex.done(function(){
		localStorage['Version_insertFuncJS_Hex'] = getInsertFuncHex.responseText.replace(/\s/g, '');
		if ($.inArray(localStorage['App_Version'], oldVersions) == -1) {
			if (Math.floor(localStorage['Version_insertFuncJS']) < Math.floor(localStorage['Version_insertFuncJS_get'])) {
				localStorage['Version_insertFuncJS'] = localStorage['Version_insertFuncJS_get'];
				console.log('[UPDATER]: Update insertFunc.js to newer version '+localStorage['Version_insertFuncJS']+' from '+localStorage['Version_insertFuncJS_Date']);
				
				var getInsertFuncCode = $.ajax({url:'https://app.mcrozz.net/Twitch.tv_Notifier/insertFunc_code.php'});
				getInsertFuncCode.done(function() { 
					localStorage['code_insertFunc'] = getInsertFuncCode.responseText;
					console.log('[UPDATER]: Success update insertFunc.js');
					SubtractTimes = Math.abs(new Date() - new Date(localStorage['Version_insertFuncJS_Date'])) / 1000;
					SubtractTimes = Math.floor(SubtractTimes);
					Days = Math.floor((SubtractTimes % 31536000) / 86400);
					Hours = Math.floor(((SubtractTimes % 31536000) % 86400) / 3600);
					Minutes = Math.floor((((SubtractTimes % 31536000) % 86400) % 3600) / 60);
					Seconds = (((SubtractTimes % 31536000) % 86400) % 3600) % 60;
					if (Days == 0) {Days = ''} else { if (Days < 10) {Days = '0'+Days+'d:'} else if (Days >= 10) {Days = Days+'d:'} };
					if (Hours == 0) {Hours = ''} else { if (Hours < 10) {Hours = '0'+Hours+'h:'} else if (Hours >= 10) {Hours = Hours+'h:'} };
					if (Minutes == 0) {Minutes = ''} else { if (Minutes < 10) {Minutes = '0'+Minutes+'m:'} else if (Minutes >= 10) {Minutes = Minutes+'m'} };
					LastEdit = Days+''+Hours+''+Minutes;
					notifyUser('Success update insertFunc.js','Ver. '+localStorage['Version_insertFuncJS']+' (edited '+LastEdit+')','ScriptUpdate');
					// Check insertFunc.js sums
					if (hex_md5(localStorage['code_insertFunc']) != localStorage['Version_insertFuncJS_Hex']) {
						localStorage['Version_insertFuncJS'] = '0';
						console.error('[UPDATER]: insertFunc.js is broken, redownload...');
						//location.reload()
					}
					//
					location.reload();
				});
			} else {
				SubtractTimes = Math.abs(new Date() - new Date(localStorage['Version_insertFuncJS_Date'])) / 1000;
				SubtractTimes = Math.floor(SubtractTimes);
				Days = Math.floor((SubtractTimes % 31536000) / 86400);
				Hours = Math.floor(((SubtractTimes % 31536000) % 86400) / 3600);
				Minutes = Math.floor((((SubtractTimes % 31536000) % 86400) % 3600) / 60);
				Seconds = (((SubtractTimes % 31536000) % 86400) % 3600) % 60;
				if (Days == 0) {Days = ''} else { if (Days < 10) {Days = '0'+Days+'d:'} else if (Days >= 10) {Days = Days+'d:'} };
				if (Hours == 0) {Hours = ''} else { if (Hours < 10) {Hours = '0'+Hours+'h:'} else if (Hours >= 10) {Hours = Hours+'h:'} };
				if (Minutes == 0) {Minutes = ''} else { if (Minutes < 10) {Minutes = '0'+Minutes+'m:'} else if (Minutes >= 10) {Minutes = Minutes+'m'} };
				LastEdit = Days+''+Hours+''+Minutes;
				console.log('[UPDATER]: insertFunc.js is up to date (edited '+LastEdit+' ago)')
			}
		}
	});
	getInsertFuncHex.fail(function(){
		console.error("[UPDATER]: Can't get hash code of insertFunc.js from server...");
		
		// If client can't reach server
		if (Math.floor(localStorage['Version_insertFuncJS']) < Math.floor(acceptedVersions.insertFunc)) {
			var getInsertFuncCode = $.ajax({url:'./offline/insertFunc_code.php'});
			getInsertFuncCode.done(function() { 
				localStorage['code_insertFunc'] = getInsertFuncCode.responseText;
				localStorage['Version_insertFuncJS'] = acceptedVersions.insertFunc;
			});
		}
		//
	});
	// End of update insertFunc.js
	//
	//
}

function ManualUpdate(name) {
	if (name == 'Back') {
		var getBackgroundCode = $.ajax({url:'https://app.mcrozz.net/Twitch.tv_Notifier/Background_code.php'});
		getBackgroundCode.done(function() { 
			localStorage['code_Background'] = getBackgroundCode.responseText;
			console.error('Success')
		});
		getBackgroundCode.error(function() { console.error('Failed') } )
	} else if (name == 'Pop') {
		var getPopupCode = $.ajax({url:'https://app.mcrozz.net/Twitch.tv_Notifier/Popup_code.php'});
		getPopupCode.done(function() { 
			localStorage['code_Popup'] = getPopupCode.responseText;
			console.error('Success')
		});
		getPopupCode.error(function() { console.error('Failed') } )
	} else if (name == 'Insert') {
		var getInsertFuncCode = $.ajax({url:'https://app.mcrozz.net/Twitch.tv_Notifier/insertFunc_code.php'});
		getInsertFuncCode.done(function() { 
			localStorage['code_insertFunc'] = getInsertFuncCode.responseText;
			console.error('Success')
		});
		getInsertFuncCode.error(function() { console.error('Failed') } )
	} else if (name == 'All') {
		var getInsertFuncCode = $.ajax({url:'https://app.mcrozz.net/Twitch.tv_Notifier/insertFunc_code.php'});
		getInsertFuncCode.done(function() { 
			localStorage['code_insertFunc'] = getInsertFuncCode.responseText;
			console.error('Success')
		});
		getInsertFuncCode.error(function() { console.error('Failed') } );

		var getPopupCode = $.ajax({url:'https://app.mcrozz.net/Twitch.tv_Notifier/Popup_code.php'});
		getPopupCode.done(function() { 
			localStorage['code_Popup'] = getPopupCode.responseText;
			console.error('Success')
		});
		getPopupCode.error(function() { console.error('Failed') } );

		var getBackgroundCode = $.ajax({url:'https://app.mcrozz.net/Twitch.tv_Notifier/Background_code.php'});
		getBackgroundCode.done(function() { 
			localStorage['code_Background'] = getBackgroundCode.responseText;
			console.error('Success')
		});
		getBackgroundCode.error(function() { console.error('Failed') } )
	} else if (name != 'Back' && name != 'Pop' && name != 'Insert') {
		console.error('Failed')
	}
}

function ConvertTime() {
	console.log(new Date(new Date()).toISOString())
}

CheckForUpdates();
setInterval(CheckForUpdates,1000*60*10)