//
// @author Ivan 'MacRozz' Zarudny
//

NotificationVar = {};
$.getJSON('/manifest.json', function(data){ localStorage['App_Version']=data.version });

function createCookie(name,value,days) {
	if (days) {
		var date = new Date();
		date.setTime(date.getTime()+(days*24*60*60*1000));
		expires = "; expires="+date.toGMTString();
	}
	else expires = "";
	document.cookie = name+"="+value+expires+"; path=/";
}

function readCookie(name) {
	var nameEQ = name + "=";
	var ca = document.cookie.split(';');
	for(var i=0;i < ca.length;i++) {
		var c = ca[i];
		while (c.charAt(0)==' ') c = c.substring(1,c.length);
		if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
	}
	return null;
}

function delCookie(name) {
    document.cookie = name + '=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
}

function BadgeOnlineCount(count) {
	if (count == '0') {
		chrome.browserAction.setBadgeText({text: String('')})
	} else {
		chrome.browserAction.setBadgeText({text: String(count)})
	}
}

function sendNotify(Title, msg, check) {
	NotificationVar[localStorage['TempSum']] = webkitNotifications.createNotification('goesOnline.png', Title, msg);
	if (check == localStorage['TempSum']) {
		console.error(new Date+' : '+Title+' -  '+msg);
		NotificationVar[check].show();
		setTimeout(function(){ NotificationVar[check].cancel() },1000 * 8);
		if (readCookie('conf_Sound') == 'Enable') {
			Audio = document.createElement('audio');
			MusicName = '/Music/'+readCookie('conf_Sound_Name')+'.mp3';
			Audio.setAttribute('src', MusicName);
			Audio.setAttribute('autoplay', 'autoplay');
			Audio.play()
		}
	} else if (check != localStorage['TempSum']) {console.error('Security Check Notification: Denied')}
}

function notifyUser(streamerName, titleOfStream, type) {
	CheckSumKey = Math.floor(Math.random()*99);
	localStorage['TempSum'] = CheckSumKey;
	if (readCookie('conf_Notify') == 'Enable') {
		if (type == 'Update') {
			sendNotify(streamerName, titleOfStream, CheckSumKey)
		} else if (type == 'Online') {
			sendNotify(streamerName, titleOfStream, CheckSumKey)
		}
	} if (readCookie('conf_Notify_Online') == 'Enable') {
		if (type == 'Online') {
			sendNotify(streamerName, titleOfStream, CheckSumKey)
		}
	} if (readCookie('conf_Notify_Update') == 'Enable') {
		if (type == 'Update') {
			sendNotify(streamerName, titleOfStream, CheckSumKey)
		}
	} if (type == 'ScriptUpdate') {
		sendNotify(streamerName, titleOfStream, CheckSumKey)
	}
}

function AppVersion(type, ver) {
	if (type == 'Version') {
		VersionUnit = 'ver. ';
		VersionUnit += localStorage['App_Version'];
		VersionUnit += ' (changes)';
		
		document.getElementById('AppVersionClick').innerHTML = VersionUnit
	}
}

if ( Math.floor(localStorage['Version_BackgroundJS']) < Math.floor(localStorage['Version_BackgroundJS_get']) ) {Background = 'Out dated'} else {Background = 'New'}
if ( Math.floor(localStorage['Version_PopupJS']) < Math.floor(localStorage['Version_PopupJS_get']) ) {Popup = 'Out dated'} else {Popup = 'New'}
if ( Math.floor(localStorage['Version_insertFuncJS']) < Math.floor(localStorage['Version_insertFuncJS_get']) ) {insertFunc = 'Out dated'} else {insertFunc = 'New'}


var _gaq = _gaq || [];
_gaq.push(['_setAccount', 'UA-25472862-3']);
_gaq.push(['_trackPageview']);
_gaq.push(['_trackEvent', 'App Version', localStorage['App_Version']]);
_gaq.push(['_trackEvent', 'BackgroundJS version', Background]);
_gaq.push(['_trackEvent', 'PopupJS version', Popup]);
_gaq.push(['_trackEvent', 'insertFuncJS version', insertFunc]);

(function() {
	var ga = document.createElement('script'); 
	ga.type = 'text/javascript'; 
	ga.async = true;
	ga.src = 'https://ssl.google-analytics.com/ga.js';
	var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
})();