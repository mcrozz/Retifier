_gaq.push(['_trackPageview']);

var NumberOfidOfListOfFollowedChannels = 1,
	LinesInListOfFollowedChannels = 0;
TimersetToUpdate = [];
OnlyIdOfListOfFollowedChannels = 'InsertFollowedChannelsHere';
FirstLoadVar = 1;
openCloseVersionVar = 1;
openCloseReportVar = 1;

function insertText(content,stream_id) {
	if (stream_id == 'stream_streamer') {
		document.getElementById(stream_id).href='http://www.twitch.tv/' + content;
	} else if (stream_id == 'stream_game') {
		document.getElementById(stream_id).href='http://www.twitch.tv/directory/game/' + content;
	} else if (stream_id == 'stream_img') {
		document.getElementById(stream_id).setAttribute('style', 'background:url(' + content + ')')
	} else {
		document.getElementById(stream_id).innerHTML=content
	}
};

function clickChangeUser() {
	document.getElementById("userChangePopup").style.display = 'block';
	document.getElementById("userChangePopup2").setAttribute("style","display:block");
	document.getElementById("userChangePopup").setAttribute("style","left:173");
	document.getElementById("ChgUsrNam").value=readCookie('UserName');
	document.getElementById("ChgUsrInt").value=readCookie('RefreshInt');
	document.getElementById('fndAbug').setAttribute("style","display:block;top:190;right:-68");
	createCookie('userChangePopup','open',1);
	changeNotify('Checking');
	checkSoundEnable('Checking');
	checkStreamDuration('Checking');
	_gaq.push(['_trackEvent', 'Options', 'clicked']);
}

function clickChangeUserCls() {
	document.getElementById("userChangePopup").style.display = 'none';
	document.getElementById("userChangePopup2").setAttribute("style","display:none");
	document.getElementById('fndAbug').setAttribute("style","display:none");
	document.getElementById("FoundAbugText").setAttribute('style', 'display:none');
	createCookie('userChangePopup','closed',1);
	openCloseReportVar = 1;
}

function changeUserName() {
	if (document.getElementById("ChgUsrNam").value != readCookie('UserName')) {
		createCookie('InstatntCheck','1',365)
		createCookie('UserName',document.getElementById("ChgUsrNam").value,365)
	} else if (document.getElementById("ChgUsrNam").value == '') {
		createCookie('UserName','Guest',365)
	}
}

function changeReftInt() {
	if (!isNaN(document.getElementById("ChgUsrInt").value)) {
		createCookie('RefreshInt',document.getElementById("ChgUsrInt").value,365)
	}
}

function changeNotify(type) {
	if (type == 'Change') {
		if (readCookie('changed_Notify') == '1') {
			if (document.getElementById('Notify').checked) {
				createCookie('conf_Notify','Enable',365);
				createCookie('conf_Notify_Online','Disable',365);
				createCookie('conf_Notify_Update','Disable',365);
				createCookie('changed_Notify','0',365)
			} else {createCookie('changed_Notify','0',365)}
		} else if (readCookie('changed_Notify_Streamer') == '1') {
			if (document.getElementById('NotifyStreamer').checked) {
				createCookie('conf_Notify','Disable',365);
				createCookie('conf_Notify_Online','Enable',365);
				createCookie('conf_Notify_Update','Disable',365);
				createCookie('changed_Notify_Streamer','0',365)
			} else {createCookie('changed_Notify_Streamer','0',365)}
		} else if (readCookie('changed_Notify_Update') == '1') {
			if (document.getElementById('NotifyUpdate').checked) {
				createCookie('conf_Notify','Disable',365);
				createCookie('conf_Notify_Online','Disable',365);
				createCookie('conf_Notify_Update','Enable',365);
				createCookie('changed_Notify_Update','0',365)
			} else {createCookie('changed_Notify_Update','0',365)}
		}
	} else if (type == 'Checking') {
		if (readCookie('conf_Notify') == 'Enable') {
			document.getElementById('Notify').checked = true;
			document.getElementById('NotifyStreamer').checked = false;
			document.getElementById('NotifyUpdate').checked = false
		} else if (readCookie('conf_Notify_Update') == 'Enable') {
			document.getElementById('Notify').checked = false;
			document.getElementById('NotifyStreamer').checked = false;
			document.getElementById('NotifyUpdate').checked = true
		} else if (readCookie('conf_Notify_Online') == 'Enable') {
			document.getElementById('Notify').checked = false;
			document.getElementById('NotifyStreamer').checked = true;
			document.getElementById('NotifyUpdate').checked = false
		}
	}
}

function checkModifyNotify() {
	document.getElementById('NotifyStreamer').checked = false;
	document.getElementById('NotifyUpdate').checked = false;
	createCookie('changed_Notify','1',365)
}

function checkModifyNotifyStreamer() {
	document.getElementById('Notify').checked = false;
	document.getElementById('NotifyUpdate').checked = false;
	createCookie('changed_Notify_Streamer','1',365)
}

function checkModifyNotifyUpdate() {
	document.getElementById('Notify').checked = false;
	document.getElementById('NotifyStreamer').checked = false;
	createCookie('changed_Notify_Update','1',365)
}

function openCloseReportAbug() {
	_gaq.push(['_trackEvent', 'Report a bug', 'clicked']);
	
	if (readCookie('userChangePopup') == 'open') {
		if (openCloseReportVar == 1) {
			document.getElementById("FoundAbugText").setAttribute('style', 'display:block;right:0;top:121');
			document.getElementById("fndAbug").setAttribute('style', 'right:95;top:190');
			openCloseReportVar = 0
		} else if (openCloseReportVar == 0) {
			document.getElementById("FoundAbugText").setAttribute('style', 'display:none');
			document.getElementById("fndAbug").setAttribute('style', 'display:block;top:190;right:-68');
			openCloseReportVar = 1
		}
	} else if (readCookie('AppChanges') == 'open') {
		if (openCloseReportVar == 1) {
			document.getElementById("FoundAbugText").setAttribute('style', 'display:block;right:0;top:21');
			document.getElementById("fndAbug").setAttribute('style', 'right:95;top:90');
			openCloseReportVar = 0
		} else if (openCloseReportVar == 0) {
			document.getElementById("FoundAbugText").setAttribute('style', 'display:none');
			document.getElementById("fndAbug").setAttribute('style', 'display:block;top:90;right:-68');
			openCloseReportVar = 1
		}
	}
};

function checkSoundEnable(type) {
	if (type == 'Change') {
		if (document.getElementById('SoundCheck').checked == true) {
			createCookie('conf_Sound','Enable',365)
		} else if (document.getElementById('SoundCheck').checked == false) {
			createCookie('conf_Sound','Disable',365)
		}
	} else if (type == 'Checking') {
		if (readCookie('conf_Sound') == 'Enable') {
			document.getElementById('SoundCheck').checked = true
		} else if (readCookie('conf_Sound') == 'Disable') {
			document.getElementById('SoundCheck').checked = false
		}
	}
}

function checkStreamDuration(type) {
	if (type == 'Change') {
		if (document.getElementById('StreamDurationCheck').checked == true) {
			createCookie('conf_StreamDuration','Enable',365)
		} else if (document.getElementById('StreamDurationCheck').checked == false) {
			createCookie('conf_StreamDuration','Disable',365)
		}
	} else if (type == 'Checking') {
		if (readCookie('conf_StreamDuration') == 'Enable') {
			document.getElementById('StreamDurationCheck').checked = true
		} else if (readCookie('conf_StreamDuration') == 'Disable') {
			document.getElementById('StreamDurationCheck').checked = false
		}
	}
}

function changeScriptStarter() {
	changeSoundFile('Change');
	changeUserName();
	changeReftInt();
	changeNotify('Change');
	checkSoundEnable('Change');
	checkStreamDuration('Change');
	clickChangeUserCls()
}

function FollowedChannelsList(content,status) {
	if (content != undefined) {
		if (LinesInListOfFollowedChannels == '19') {
			NumberOfidOfListOfFollowedChannels += 1;
		
			idOfListOfFollowedChannels = '';		
		
			idOfListOfFollowedChannels += OnlyIdOfListOfFollowedChannels;		
			idOfListOfFollowedChannels += NumberOfidOfListOfFollowedChannels;
		
			if (NumberOfidOfListOfFollowedChannels == '6') {
				LinesInListOfFollowedChannels = 0
			};
		} else {
			idOfListOfFollowedChannels = '';		
		
			idOfListOfFollowedChannels += OnlyIdOfListOfFollowedChannels;		
			idOfListOfFollowedChannels += NumberOfidOfListOfFollowedChannels
		}
	
		if (status == 'Online') {
			statusColor = 'rgb(0, 194, 40)'
		} else {
			statusColor = 'black'
		}
		
		mydiv = document.getElementById(idOfListOfFollowedChannels);
		newcontent = document.createElement('div');
		newcontent.innerHTML = '<a href="http://www.twitch.tv/'+content+'/profile" style="color:'+statusColor+';border-bottom:1px black dotted" target="_blank">'+content+'</a><br>';
	
		LinesInListOfFollowedChannels += 1;

		while (newcontent.firstChild) {
			mydiv.appendChild(newcontent.firstChild);
		}
	}
	// If 19 lines then go to next sector
	// InsertFollowedChannelsHere + Number (From 1 to 4)
}

function openFollowedList() {
	document.getElementById("firstScane").setAttribute("style","display:none");
	document.getElementById("FollowedChannelsList").setAttribute("style","display:block");
	_gaq.push(['_trackEvent', 'Following List', 'clicked']);

	var CountOfChannels = [];
	CountOfChannels.length = localStorage['NumberOfChecked'].length;
	CreateVarForEach = 0;
	CountOfRetryEach = 1;
	
	$.each(CountOfChannels, function() {
		StorageName = 'Stream_Name_';
		StorageName += CountOfRetryEach;
		KeyForStorageName = localStorage[StorageName];
		
		StorageStatus = 'Stream_Status_';
		StorageStatus += CountOfRetryEach;
		KeyForStorageStatus = localStorage[StorageStatus];
		
		FollowedChannelsList(KeyForStorageName,KeyForStorageStatus);
		
		CountOfRetryEach += 1;
	})
}

function closeFollowedList() {
	document.getElementById("firstScane").setAttribute("style","display:block");
	document.getElementById("FollowedChannelsList").setAttribute("style","display:none");
	insertText('','InsertFollowedChannelsHere1');
	insertText('','InsertFollowedChannelsHere2');
	insertText('','InsertFollowedChannelsHere3');
	insertText('','InsertFollowedChannelsHere4');
	insertText('','InsertFollowedChannelsHere5');
	insertText('','InsertFollowedChannelsHere6');
	NumberOfidOfListOfFollowedChannels = 1;
	LinesInListOfFollowedChannels = 0
}

function openAppVersionChanges() {
	_gaq.push(['_trackEvent', 'App changes', 'clicked']);
	if (openCloseVersionVar == 1) {
		document.getElementById('AppChanges').setAttribute('style', 'display:block');
		document.getElementById('body').setAttribute('style', 'overflow:hidden');
		document.getElementById('fndAbug').setAttribute("style","display:block");
		document.getElementById("AppInfoBack").setAttribute("style","display:block");
		changeAppContent('AppFirst');
		document.getElementById("fndAbug").setAttribute('style', 'display:block;top:90;right:-68');
		createCookie('AppChanges','open',1);
		openCloseVersionVar = 0
	} else if (openCloseVersionVar == 0) {
		document.getElementById('fndAbug').setAttribute("style","display:none");
		document.getElementById("FoundAbugText").setAttribute('style', 'display:none');
		createCookie('AppChanges','closed',1);
		document.getElementById('AppChanges').setAttribute('style', 'display:none');
		document.getElementById('body').setAttribute('style', 'overflow:auto');
		document.getElementById('fndAbug').setAttribute("style","display:none");
		document.getElementById("AppInfoBack").setAttribute("style","display:none");
		openCloseVersionVar = 1
	}
}

function changeAppContent(App) {
	if (App == 'AppFirst') {
	
		AppFirst = "<div class='AppInfo'><a class='aAppInfo'>-1.1.6 Bug fixes</a></div>";
		AppFirst += "<div class='AppInfo'><a class='aAppInfo'>-1.1.5 A little optimisation in style. Now you can disable duration of stream. Button 'Found a bug?' now only viewable in options and in changes</a></div>";
		AppFirst += '<div class="AppInfo"><a class="aAppInfo">-1.1.4 Fixed freezes on opening</a></div>';
		AppFirst += '<div class="AppInfo"><a class="aAppInfo">-1.1.3 Bug with notifications, fixed stream duration</a></div>';
		AppFirst += '<div class="AppInfo"><a class="aAppInfo">-1.1.2 Stream duration</a></div>';
		AppFirst += '<div class="AppInfo"><a class="aAppInfo">-1.1.1 Hotfix</a></div>';
		AppFirst += '<div class="AppInfo"><a class="aAppInfo">-1.1.0 Added sound effects for notifications. Added "Version changes" page. And more...</a></div>';
		AppFirst += '<div class="AppInfo"><a class="aAppInfo">-1.0.2 Resolved a problem which freezes app</a></div>';
		AppFirst += '<div class="AppInfo"><a class="aAppInfo">-1.0.1 Bug fixes</a></div>';
		AppFirst += '<div class="AppInfo"><a class="aAppInfo">-1.0.0 First publish in Google Web Store</a></div>';
		
		document.getElementById('AppVersionContent').innerHTML = AppFirst
	} else if (App == 'AppSecond') {
	
		AppSecond = '<div class="AppInfoFuture"><a class="aAppInfoFuture">-Animation</a></div>';
		
		document.getElementById('AppVersionContent').innerHTML = AppSecond
	} else if (App == 'AppThird') {
	
		AppThird = '<div class="AppInfoAbout1"><a class="aAppInfoAbout1">This extension developed and published by</a></div>';
		AppThird += "<div class='AppInfoAbout2'><a class='aAppInfoAbout2'>Ivan 'MacRozz' Zarudny</a></div>";
		AppThird += "<div class='AppInfoAbout3'><a class='aAppInfoAbout3' href='http://www.mcrozz.net' target='_blank'>My website www.mcrozz.net</a></div>";
		AppThird += "<div class='AppInfoAbout4'><a class='aAppInfoAbout4' href='http://www.twitter.com/iZarudny' target='_blank'>Twitter @iZarudny</a></div>";
		AppThird += "<div class='AppInfoAbout5'><a class='aAppInfoAbout5' href='https://chrome.google.com/webstore/detail/twitchtv-notifier/mmemeoejijknklekkdacacimmkmmokbn/reviews' target='_blank'>Don't forget to rate my app ;)</a></div>";
		
		document.getElementById('AppVersionContent').innerHTML = AppThird
	}
}

function changeSoundFile(type) {
	if (type != 'Change') {
		var Audio = document.createElement('audio');
		MusicName = '/Music/'+document.getElementById("SoundSelect").value+'.mp3';
		Audio.setAttribute('src', MusicName);
		Audio.setAttribute('autoplay', 'autoplay');
		Audio.play()
	} else if (type == 'Change'){
		createCookie('conf_Sound_Name',document.getElementById("SoundSelect").value,365)
	}
}

function progressBar(type) {
	if (type == 'Enable') {
		document.getElementById('CheckingProgress').setAttribute('style', 'display:block');
		CheckedPercent = 100 / localStorage['FollowingChannels'] * localStorage['NumberOfChecked'].length;
		document.getElementById('CheckingProgress').value = CheckedPercent
	} else if (type == 'Disable') {
		document.getElementById('CheckingProgress').setAttribute('style', 'display:none')
	}
}

document.addEventListener( "DOMContentLoaded" , function () {
	AppVersion('Version');
	document.getElementById("ChgUsr").addEventListener( "click" , clickChangeUser);
	document.getElementById("ChgUsrSnd").addEventListener( "click" , changeScriptStarter);
	document.getElementById("LstFlwdChnls").addEventListener( "click" , openFollowedList);
	document.getElementById("ClsFlwdChnlsLst").addEventListener( "click" , closeFollowedList);
	document.getElementById("Notify").addEventListener("change", checkModifyNotify);
	document.getElementById("NotifyStreamer").addEventListener("change", checkModifyNotifyStreamer);
	document.getElementById("NotifyUpdate").addEventListener("change", checkModifyNotifyUpdate);
	document.getElementById("fndAbug").addEventListener("click", openCloseReportAbug);
	document.getElementById("AppVersionClick").addEventListener("click", openAppVersionChanges);
	document.getElementById("SoundSelect").addEventListener("change", changeSoundFile);
	document.getElementById("AppFirst").addEventListener("click", function(){changeAppContent('AppFirst')});
	document.getElementById("AppSecond").addEventListener("click", function(){changeAppContent('AppSecond')});
	document.getElementById("AppThird").addEventListener("click", function(){changeAppContent('AppThird')});
	document.getElementById("AppInfoClose").addEventListener("click", function(){document.getElementById('AppChanges').setAttribute('style', 'display:none');document.getElementById("AppInfoBack").setAttribute("style","display:none");openCloseVersionVar = 1;document.getElementById('fndAbug').setAttribute("style","display:none");createCookie('AppChanges','closed',1);document.getElementById("FoundAbugText").setAttribute('style', 'display:none')});
	document.getElementById('userChangePopup2').addEventListener('click', function(){clickChangeUserCls()});
	document.getElementById('AppInfoBack').addEventListener('click', function(){document.getElementById('AppChanges').setAttribute('style', 'display:none');document.getElementById("AppInfoBack").setAttribute("style","display:none");openCloseVersionVar = 1;document.getElementById('fndAbug').setAttribute("style","display:none");createCookie('AppChanges','closed',1);document.getElementById("FoundAbugText").setAttribute('style', 'display:none')});
	document.getElementById('Dashboard').addEventListener('click', function(){_gaq.push(['_trackEvent', 'Dashboard', 'clicked']);window.open('http://www.twitch.tv/broadcast/dashboard')});
	document.getElementById('Direct').addEventListener('click', function(){_gaq.push(['_trackEvent', 'Direct', 'clicked']);window.open('http://www.twitch.tv/directory/following')});
} );

