//
// @author Ivan 'MacRozz' Zarudny
//

FirstLoadInsertFunc = 1;

function insertOnlineListFunc(content,idToInsert) {
	InsertText = document.getElementById(idToInsert).innerHTML;
	InsertText += content;
	document.getElementById(idToInsert).innerHTML = InsertText;
};

function InsertOnlineList() {
	TimersetToUpdate = [];
	var CountOfChannels = [];
	CountOfRetryEach = 0;
	if (localStorage['NumberOfChecked']) {
		CountOfChannels.length = localStorage['NumberOfChecked']
	} else {
		CountOfChannels.length = null
	};
	if (document.getElementById('insertContentHere')) {
		document.getElementById('insertContentHere').innerHTML = null
	}
	
	localStorage['ShowWaves'] = 'true';
	
	
	$.each(CountOfChannels, function() {
	setTimeout(function(){
		JustAvariable = 'Stream_Status_';
		TumbURL = 'Stream_Tumb_';
		StreamTitle = 'Stream_Title_';
		StreamerName = 'Stream_Name_';
		StreamViewers = 'Stream_Viewers_';
		StreamGame = 'Stream_Game_';
		StreamTime = 'Stream_Time_';
		JustAvariable += CountOfRetryEach;
		TumbURL += CountOfRetryEach;
		StreamTitle += CountOfRetryEach;
		StreamerName += CountOfRetryEach;
		StreamViewers += CountOfRetryEach;
		StreamGame += CountOfRetryEach;
		StreamTime += CountOfRetryEach;
	
		if (localStorage[JustAvariable] == 'Online') {	
			StreamListUnit = '<div class="content">';
			StreamListUnit += '<div class="tumblr">';
			StreamListUnit += '<img target="_blank" id="stream_img_';
			StreamListUnit += CountOfRetryEach;
			StreamListUnit += '" height="200px" width="320px" scr=""';
			StreamListUnit += '</img>';
			StreamListUnit += '</div>';
			StreamListUnit += '<div class="information">';
			StreamListUnit += '<div class="title">';
			StreamListUnit += '<p class="pTitle">Title</p>';
			StreamListUnit += '<div class="informationTextTitle">';
			if (localStorage[StreamTitle].length >= 29) {
				CountToCut = localStorage[StreamTitle].length - 29;
				StreamListUnit += localStorage[StreamTitle].substring (0, localStorage[StreamTitle].length - CountToCut);
				StreamListUnit += '...';
			} else {
				StreamListUnit += localStorage[StreamTitle];
			};
			StreamListUnit += '</div>';
			StreamListUnit += '</div>';
			StreamListUnit += '<div class="streamer">';
			StreamListUnit += '<p class="pStreamer">Streamer</p>';
			StreamListUnit += '<a class="informationTextStreamer" target="_blank" href="http://www.twitch.tv/';
			StreamListUnit += localStorage[StreamerName];
			StreamListUnit += '">';
			StreamListUnit += localStorage[StreamerName];
			StreamListUnit += '</a>';
			StreamListUnit += '</div>';
			StreamListUnit += '<div class="viewers">';
			StreamListUnit += '<p class="pViewers">Viewers</p>';
			StreamListUnit += '<div class="informationTextViewers">';
			StreamListUnit += localStorage[StreamViewers];
			StreamListUnit += '</div>';
			StreamListUnit += '</div>';
			StreamListUnit += '<div class="gamename">';
			StreamListUnit += '<p class="pGamename">Game</p>';
			StreamListUnit += '<a class="informationTextGame" target="_blank" id="stream_game_'
			StreamListUnit += CountOfRetryEach;
			StreamListUnit += '">';
			if (localStorage[StreamGame].length >= 29) {
				CountToCut = localStorage[StreamGame].length - 29;
				StreamListUnit += localStorage[StreamGame].substring (0, localStorage[StreamGame].length - CountToCut);
				StreamListUnit += '...';
			} else {
				StreamListUnit += localStorage[StreamGame];
			};
			StreamListUnit += '</a>';
			StreamListUnit += '</div>';
			StreamListUnit += '<div class="StreamOnChannelPage">';
			StreamListUnit += '<button type="button" name="Go to a stream page" class="button">';
			StreamListUnit += '<a href="http://www.twitch.tv/'
			StreamListUnit += localStorage[StreamerName];
			StreamListUnit += '"class="aStreamOnChannelPage" target="_blank">';
			StreamListUnit += 'Channel page';
			StreamListUnit += '</a>';
			StreamListUnit += '</button>';
			StreamListUnit += '<a id="Stream_Duration_';
			StreamListUnit += CountOfRetryEach;
			StreamListUnit += '" class="StreamDuration">';
			StreamListUnit += '</a>';
			StreamListUnit += '</div>';
			StreamListUnit += '</div>';
			StreamListUnit += '</div>';
			
			if (readCookie('NowOnline') == '0') {
				localStorage['ShowWaves'] = 'true'
			} else { localStorage['ShowWaves'] = 'false' };
			
			TimersetToUpdate.push(CountOfRetryEach);
			
			insertOnlineListFunc(StreamListUnit,'insertContentHere');
			
			ElementIdIs = 'stream_img_';
			ElementIdIs += CountOfRetryEach;
			document.getElementById(ElementIdIs).setAttribute('style','background:url('+localStorage[TumbURL]+')');
			
			
			document.getElementById(ElementIdIs).href = 'http://www.twitch.tv/'+localStorage[StreamerName];
			
			ElementIdIs2 = 'stream_game_';
			ElementIdIs2 += CountOfRetryEach;
			document.getElementById(ElementIdIs2).href = 'http://www.twitch.tv/directory/game/'+localStorage[StreamGame];
		} if (CountOfRetryEach == Math.floor(localStorage['NumberOfChecked'])) {
			console.log('Insert Online List finished!')
		}
		CountOfRetryEach += 1;
	},1);
	} );
}

InsertOnlineList();

setInterval(function(){
	if (FirstLoadInsertFunc == 1) {
		localStorage['InsertOnlineList'] = '0';
		FirstLoadInsertFunc = 0
	} else if (FirstLoadInsertFunc == 0) {
		if (localStorage['InsertOnlineList'] == '1') {
			InsertOnlineList();
			localStorage['InsertOnlineList'] = '0'
		}
	}
}, 1000);

setInterval(function(){
	/*
	StatusUpdate : 
	
	-0 - Not updating, finished
	-1 - Timer ended, start update
	-2 - Update list of followed channels
	-3 - List of followed channels updated
	-4 - Checking online channel or not
	-5 - Error
	-6 - Name doesn't set up!

	*/
	if (readCookie('StatusUpdate') == '0') {
		insertText('Now online '+readCookie('NowOnline')+' from '+localStorage['ChannelsCount'],'FollowedChannelsOnline');
		progressBar('Disable')
	} else if (readCookie('StatusUpdate') == '1') {
		insertText('Behold! Update!','FollowedChannelsOnline')
	} else if (readCookie('StatusUpdate') == '2') { 
		insertText('Updating list of followed channels...','FollowedChannelsOnline')
	} else if (readCookie('StatusUpdate') == '3') { 
		insertText('List of followed channels updated.','FollowedChannelsOnline')
	} else if (readCookie('StatusUpdate') == '4') { 
		insertText('Now online '+readCookie('NowOnline')+' from '+localStorage['ChannelsCount'],'FollowedChannelsOnline');
		progressBar('Enable')
	} else if (readCookie('StatusUpdate') == '5') { 
		insertText('App had a problem with update','FollowedChannelsOnline')
	} else if (readCookie('StatusUpdate') == '6') { 
		insertText("Name doesn't set up yet!",'FollowedChannelsOnline')
	}
	
	if (localStorage['ShowWaves'] == 'true') {
		document.getElementById('NoOneOnline').setAttribute('style', 'display:block')
	} else if (localStorage['ShowWaves'] == 'false') {
		document.getElementById('NoOneOnline').setAttribute('style', 'display:none')
	}
}, 100);

setInterval(function(){
	if (readCookie('conf_StreamDuration') == 'Enable') {
		number = 0;
		$.each(TimersetToUpdate, function() {
			InsertTimeHere = 'Stream_Duration_';
			InsertTimeHere += TimersetToUpdate[number];
			StreamDurationTime = 'Stream_Time_';
			StreamDurationTime += TimersetToUpdate[number];
			// POWER OF MATH
			SubtractTimes = Math.abs(new Date() - new Date(localStorage[StreamDurationTime])) / 1000;
			SubtractTimes = Math.floor(SubtractTimes);
			Days = Math.floor((SubtractTimes % 31536000) / 86400);
			Hours = Math.floor(((SubtractTimes % 31536000) % 86400) / 3600);
			Minutes = Math.floor((((SubtractTimes % 31536000) % 86400) % 3600) / 60);
			Seconds = (((SubtractTimes % 31536000) % 86400) % 3600) % 60;
			if (Days == 0) {Days = ''} else { if (Days < 10) {Days = '0'+Days+'d:'} else if (Days >= 10) {Days = Days+'d:'} };
			if (Hours == 0) {Hours = ''} else { if (Hours < 10) {Hours = '0'+Hours+'h:'} else if (Hours >= 10) {Hours = Hours+'h:'} };
			if (Minutes == 0) {Minutes = ''} else { if (Minutes < 10) {Minutes = '0'+Minutes+'m:'} else if (Minutes >= 10) {Minutes = Minutes+'m:'} };
			if (Seconds == 0) {Seconds = '00s'} else { if (Seconds < 10) {Seconds = '0'+Seconds+'s'} else if (Seconds >= 10) {Seconds = Seconds+'s'} };
			Time = Days+''+Hours+''+Minutes+''+Seconds;
			if (document.getElementById(InsertTimeHere)) {document.getElementById(InsertTimeHere).innerHTML = Time};
			number += 1
			if (number-1 == TimersetToUpdate.length) {number = 0}
		})
	}
},1000);