var NumberOfidOfListOfFollowedChannels = 1,
	LinesInListOfFollowedChannels = 0;
OnlyIdOfListOfFollowedChannels = 'InsertFollowedChannelsHere';
FirstLoadVar = 1;
openCloseReportVar = 1;

function insertText(content,stream_id) {
	if (stream_id == 'stream_streamer') {
		document.getElementById(stream_id).href='http://www.twitch.tv/' + content;
	} else if (stream_id == 'stream_game') {
		document.getElementById(stream_id).href='http://www.twitch.tv/directory/game/' + content;
	} else if (stream_id == 'stream_img') {
		document.getElementById(stream_id).setAttribute('style', 'background:url(' + content + ')')
	} else {
		document.getElementById(stream_id).innerHTML=content
	}
};

function clickChangeUser() {
	document.getElementById("userChangePopup").setAttribute("style","display:block");
	document.getElementById("userChangePopup2").setAttribute("style","display:block");
	document.getElementById("ChgUsrNam").value=readCookie('UserName');
	document.getElementById("ChgUsrInt").value=readCookie('RefreshInt');
	createCookie('error_RefInt','0',365);
	document.getElementById("status_RefreshIntChg").innerHTML='';
	createCookie('error_UserName','0',365);
	document.getElementById("status_UserNameChg").innerHTML='';
	shiftPopupWindow('Checking');
	changeNotify('Checking')
	
};

function clickChangeUserCls() {
	document.getElementById("userChangePopup").setAttribute("style","display:none");
	document.getElementById("userChangePopup2").setAttribute("style","display:none");
	createCookie('error_RefInt','0',365);
	createCookie('error_UserName','0',365)
}

function shiftPopupWindow(shift) {
	if (shift == 'Right') {
		document.getElementById("userChangePopup").setAttribute("style","margin-left:203");
		setTimeout(function(){document.getElementById("userChangePopup").setAttribute("style","margin-left:216")}, 50);
		setTimeout(function(){document.getElementById("userChangePopup").setAttribute("style","margin-left:229")}, 100);
		setTimeout(function(){document.getElementById("userChangePopup").setAttribute("style","margin-left:242")}, 150);
		setTimeout(function(){document.getElementById("userChangePopup").setAttribute("style","margin-left:255")}, 200)
	} else if (shift == 'Dock') {
		document.getElementById("userChangePopup").setAttribute("style","margin-left:255");
		setTimeout(function(){document.getElementById("userChangePopup").setAttribute("style","margin-left:242")}, 50);
		setTimeout(function(){document.getElementById("userChangePopup").setAttribute("style","margin-left:229")}, 100);
		setTimeout(function(){document.getElementById("userChangePopup").setAttribute("style","margin-left:216")}, 150);
		setTimeout(function(){document.getElementById("userChangePopup").setAttribute("style","margin-left:203")}, 200);
		setTimeout(function(){document.getElementById("userChangePopup").setAttribute("style","margin-left:173")}, 250)
	} else if (shift == 'Checking') {
		if (readCookie('error_RefInt') == '1') {
			document.getElementById("userChangePopup").setAttribute("style","margin-left:255");
			document.getElementById("status_RefreshIntChg").setAttribute("style","display:block");
			document.getElementById("status_RefreshIntChg").setAttribute("style","color:red");
			document.getElementById("status_RefreshIntChg").innerHTML='Refresh interval are same'
		} else if (readCookie('error_UserName') == '1') {
			document.getElementById("userChangePopup").setAttribute("style","margin-left:190")
			document.getElementById("status_UserNameChg").setAttribute("style","display:block");
			document.getElementById("status_UserNameChg").setAttribute("style","color:red");
			document.getElementById("status_UserNameChg").innerHTML='User name are same'
		} else if (readCookie('error_RefInt') == '0') {
			document.getElementById("userChangePopup").setAttribute("style","margin-left:173");
			document.getElementById("status_RefreshIntChg").innerHTML=''
		} else if (readCookie('error_UserName') == '0') {
			document.getElementById("userChangePopup").setAttribute("style","margin-left:173");
			document.getElementById("status_UserNameChg").innerHTML=''
		}
	}
};

function changeUserName() {
	nameToChange = document.getElementById("ChgUsrNam").value;
	
	if (readCookie('changed_Name') == '1') {
	
		if (nameToChange == readCookie('UserName')) {
			createCookie('changed_Name','0',365); 
			createCookie('error_UserName','1',365); 
			shiftPopupWindow('Right');
			document.getElementById("status_UserNameChg").setAttribute("style","display:block");
			document.getElementById("status_UserNameChg").setAttribute("style","color:red");
			document.getElementById("status_UserNameChg").innerHTML='User name are same';
		
			document.getElementById("ChgUsrNam").setAttribute("style","background:rgba(255,0,0,0.65)");
			setTimeout(function(){document.getElementById("ChgUsrNam").setAttribute("style","background:none")},200);
			setTimeout(function(){document.getElementById("ChgUsrNam").setAttribute("style","background:rgba(255,0,0,0.65)")},400);
		
			setTimeout(function(){document.getElementById("ChgUsrNam").setAttribute("style","background:none")},600);
			setTimeout(function(){document.getElementById("ChgUsrNam").setAttribute("style","background:rgba(255,0,0,0.65)")},800);
		
			setTimeout(function(){document.getElementById("ChgUsrNam").setAttribute("style","background:none")},1000);
			setTimeout(function(){document.getElementById("ChgUsrNam").setAttribute("style","background:rgba(255,0,0,0.65)")},1200);
		
			setTimeout(function(){document.getElementById("ChgUsrNam").setAttribute("style","background:none")},1400);
			setTimeout(function(){document.getElementById("ChgUsrNam").setAttribute("style","background:rgba(255,0,0,0.65)")},1600);
		
			setTimeout(function(){document.getElementById("ChgUsrNam").setAttribute("style","background:none")},1800);
			setTimeout(function(){document.getElementById("ChgUsrNam").setAttribute("style","background:rgba(255,0,0,0.65)")},2000);
		
			setTimeout(function(){document.getElementById("ChgUsrNam").setAttribute("style","background:none")},2200)
		} else { 
			shiftPopupWindow('Right');
			createCookie('UserName',nameToChange,365);
			document.getElementById("status_UserNameChg").setAttribute("style","display:block");
			document.getElementById("status_UserNameChg").setAttribute("style","color:green");
			document.getElementById("status_UserNameChg").innerHTML='Successful update!';
			createCookie('InstatntCheck','1',365);
			createCookie('error_UserName','0',365);
			setTimeout(function(){ 
				shiftPopupWindow('Checking');
				document.getElementById("status_UserNameChg").setAttribute("style","display:none")
			}, 1000 * 4)
		}
	}
};

function changeReftInt() {
	refrIntToChange = document.getElementById("ChgUsrInt").value;

	if (readCookie('changed_Interval') == '1') {
	
		if (refrIntToChange == readCookie('RefreshInt')) {
			createCookie('changed_Interval','0',365);
			createCookie('error_RefInt','1',365); 
			shiftPopupWindow('Right');
			document.getElementById("status_RefreshIntChg").setAttribute("style","display:block");
			document.getElementById("status_RefreshIntChg").setAttribute("style","color:red");
			document.getElementById("status_RefreshIntChg").innerHTML='Refresh interval are same';
		
			document.getElementById("ChgUsrInt").setAttribute("style","background:rgba(255,0,0,0.65)");
			setTimeout(function(){document.getElementById("ChgUsrInt").setAttribute("style","background:none")},200);
			setTimeout(function(){document.getElementById("ChgUsrInt").setAttribute("style","background:rgba(255,0,0,0.65)")},400);
		
			setTimeout(function(){document.getElementById("ChgUsrInt").setAttribute("style","background:none")},600);
			setTimeout(function(){document.getElementById("ChgUsrInt").setAttribute("style","background:rgba(255,0,0,0.65)")},800);
		
			setTimeout(function(){document.getElementById("ChgUsrInt").setAttribute("style","background:none")},1000);
			setTimeout(function(){document.getElementById("ChgUsrInt").setAttribute("style","background:rgba(255,0,0,0.65)")},1200);
		
			setTimeout(function(){document.getElementById("ChgUsrInt").setAttribute("style","background:none")},1400);
			setTimeout(function(){document.getElementById("ChgUsrInt").setAttribute("style","background:rgba(255,0,0,0.65)")},1600);
		
			setTimeout(function(){document.getElementById("ChgUsrInt").setAttribute("style","background:none")},1800);
			setTimeout(function(){document.getElementById("ChgUsrInt").setAttribute("style","background:rgba(255,0,0,0.65)")},2000);
		
			setTimeout(function(){document.getElementById("ChgUsrInt").setAttribute("style","background:none")},2200)
		} else {
			shiftPopupWindow('Right');
			createCookie('RefreshInt',refrIntToChange,365);
			document.getElementById("status_RefreshIntChg").setAttribute("style","display:block");
			document.getElementById("status_RefreshIntChg").setAttribute("style","color:green");
			document.getElementById("status_RefreshIntChg").innerHTML='Successful update!';
			createCookie('error_RefInt','0',365); 
			setTimeout(function(){
				shiftPopupWindow('Checking');
				document.getElementById("status_RefreshIntChg").setAttribute("style","display:none")
			}, 1000 * 4)
		}
	}
};

function changeNotify(type) {
	if (type == 'Change') {
		if (readCookie('changed_Notify') == '1') {
			if (document.getElementById('Notify').checked) {
				createCookie('conf_Notify','Enable',365);
				createCookie('conf_Notify_Online','Disable',365);
				createCookie('conf_Notify_Update','Disable',365);
				createCookie('changed_Notify','0',365)
			} else {createCookie('changed_Notify','0',365)}
		} else if (readCookie('changed_Notify_Streamer') == '1') {
			if (document.getElementById('NotifyStreamer').checked) {
				createCookie('conf_Notify','Disable',365);
				createCookie('conf_Notify_Online','Enable',365);
				createCookie('conf_Notify_Update','Disable',365);
				createCookie('changed_Notify_Streamer','0',365)
			} else {createCookie('changed_Notify_Streamer','0',365)}
		} else if (readCookie('changed_Notify_Update') == '1') {
			if (document.getElementById('NotifyUpdate').checked) {
				createCookie('conf_Notify','Disable',365);
				createCookie('conf_Notify_Online','Disable',365);
				createCookie('conf_Notify_Update','Enable',365);
				createCookie('changed_Notify_Update','0',365)
			} else {createCookie('changed_Notify_Update','0',365)}
		}
	} else if (type == 'Checking') {
		if (readCookie('conf_Notify') == 'Enable') {
			document.getElementById('Notify').checked = true;
			document.getElementById('NotifyStreamer').checked = false;
			document.getElementById('NotifyUpdate').checked = false
		} else if (readCookie('conf_Notify_Update') == 'Enable') {
			document.getElementById('Notify').checked = false;
			document.getElementById('NotifyStreamer').checked = false;
			document.getElementById('NotifyUpdate').checked = true
		} else if (readCookie('conf_Notify_Online') == 'Enable') {
			document.getElementById('Notify').checked = false;
			document.getElementById('NotifyStreamer').checked = true;
			document.getElementById('NotifyUpdate').checked = false
		}
	}
};

function changeScriptStarter() {
	if (readCookie('changed_Name') == '0') {
		if (readCookie('changed_Interval') == '0') {
			if (readCookie('changed_Notify') == '0') {
				if (readCookie('changed_Notify_Streamer') == '0') {
					if (readCookie('changed_Notify_Update') == '0') {
						document.getElementById('status_Dialog').setAttribute("style","display:block");
						document.getElementById('status_Dialog').innerHTML = 'Nothing to change';
						setTimeout(function(){ 
							document.getElementById('status_Dialog').setAttribute("style","display:none");
							document.getElementById('status_Dialog').innerHTML = ''
						},5000)
					}
				}
			}
		}
	};

	changeUserName();
	changeReftInt();
	changeNotify('Change')
};

function FollowedChannelsList(content,status) {
	if (content == undefined) {
		//BECAUSE WE ARE HATE UNDEFINED >:I
	} else {
		if (LinesInListOfFollowedChannels == '19') {
			NumberOfidOfListOfFollowedChannels += 1;
		
			idOfListOfFollowedChannels = '';		
		
			idOfListOfFollowedChannels += OnlyIdOfListOfFollowedChannels;		
			idOfListOfFollowedChannels += NumberOfidOfListOfFollowedChannels;
		
			if (NumberOfidOfListOfFollowedChannels == '6') {
				LinesInListOfFollowedChannels = 0
			};
		} else {
			idOfListOfFollowedChannels = '';		
		
			idOfListOfFollowedChannels += OnlyIdOfListOfFollowedChannels;		
			idOfListOfFollowedChannels += NumberOfidOfListOfFollowedChannels
		};
	
		if (status == 'Online') {
			statusColor = 'rgb(0, 194, 40)'
		} else {
			statusColor = 'black'
		};
		
		mydiv = document.getElementById(idOfListOfFollowedChannels);
		newcontent = document.createElement('div');
		newcontent.innerHTML = '<a href="http://www.twitch.tv/'+content+'/profile" style="color:'+statusColor+';border-bottom:1px black dotted" target="_blank">'+content+'</a><br>';
	
		LinesInListOfFollowedChannels += 1;

		while (newcontent.firstChild) {
			mydiv.appendChild(newcontent.firstChild);
		}
	}
	// If 19 lines then go to next sector
	// InsertFollowedChannelsHere + Number (From 1 to 4)
};

function openFollowedList() {
	document.getElementById("firstScane").setAttribute("style","display:none");
	document.getElementById("FollowedChannelsList").setAttribute("style","display:block");

	var CountOfChannels = [];
	CountOfChannels.length = localStorage['NumberOfChecked'].length;
	CreateVarForEach = 0;
	CountOfRetryEach = 1;
	
	$.each(CountOfChannels, function() {
		StorageName = 'Stream_Name_';
		StorageName += CountOfRetryEach;
		KeyForStorageName = localStorage[StorageName];
		
		StorageStatus = 'Stream_Status_';
		StorageStatus += CountOfRetryEach;
		KeyForStorageStatus = localStorage[StorageStatus];
		
		if (KeyForStorageName == 'undefined') {
			console.error('!!!WARNING!!! SOMETHING WITH NUMBER '+CountOfRetryEach+' IS UNDEFINED')
		} else {
			FollowedChannelsList(KeyForStorageName,KeyForStorageStatus)
		};
		CountOfRetryEach += 1;
	})
};

function closeFollowedList() {
	document.getElementById("firstScane").setAttribute("style","display:block");
	document.getElementById("FollowedChannelsList").setAttribute("style","display:none");
	insertText('','InsertFollowedChannelsHere1');
	insertText('','InsertFollowedChannelsHere2');
	insertText('','InsertFollowedChannelsHere3');
	insertText('','InsertFollowedChannelsHere4');
	insertText('','InsertFollowedChannelsHere5');
	insertText('','InsertFollowedChannelsHere6');
	NumberOfidOfListOfFollowedChannels = 1;
	LinesInListOfFollowedChannels = 0
};

function checkModifyTextName() {
	createCookie('changed_Name','1',365)
};

function checkModifyTextInterval() {
	createCookie('changed_Interval','1',365)
};

function checkModifyNotify() {
	document.getElementById('NotifyStreamer').checked = false;
	document.getElementById('NotifyUpdate').checked = false;
	createCookie('changed_Notify','1',365)
}

function checkModifyNotifyStreamer() {
	document.getElementById('Notify').checked = false;
	document.getElementById('NotifyUpdate').checked = false;
	createCookie('changed_Notify_Streamer','1',365)
}

function checkModifyNotifyUpdate() {
	document.getElementById('Notify').checked = false;
	document.getElementById('NotifyStreamer').checked = false;
	createCookie('changed_Notify_Update','1',365)
}

function openCloseReportAbug() {
	if (openCloseReportVar == 1) {
		document.getElementById("FoundAbugText").setAttribute('style', 'display:block');
		document.getElementById("fndAbug").setAttribute('style', 'left:88');
		openCloseReportVar = 0
	} else if (openCloseReportVar == 0) {
		document.getElementById("FoundAbugText").setAttribute('style', 'display:none');
		document.getElementById("fndAbug").setAttribute('style', 'left:-68');
		openCloseReportVar = 1
	}
};

document.addEventListener( "DOMContentLoaded" , function () {
	document.getElementById("ChgUsr").addEventListener( "click" , clickChangeUser);
	document.getElementById("ChgUsrCls").addEventListener( "click" , clickChangeUserCls);
	document.getElementById("ChgUsrSnd").addEventListener( "click" , changeScriptStarter);
	document.getElementById("LstFlwdChnls").addEventListener( "click" , openFollowedList);
	document.getElementById("ClsFlwdChnlsLst").addEventListener( "click" , closeFollowedList);
	document.getElementById("ChgUsrNam").addEventListener("change", checkModifyTextName);
	document.getElementById("ChgUsrInt").addEventListener("change", checkModifyTextInterval);
	document.getElementById("Notify").addEventListener("change", checkModifyNotify);
	document.getElementById("NotifyStreamer").addEventListener("change", checkModifyNotifyStreamer);
	document.getElementById("NotifyUpdate").addEventListener("change", checkModifyNotifyUpdate);
	document.getElementById("fndAbug").addEventListener("click", openCloseReportAbug)
} );

function insertOnlineListFunc(content,idToInsert) {
	mydiv = document.getElementById(idToInsert);
	newcontent = document.createElement('div');
	newcontent.innerHTML = content;

	while (newcontent.firstChild) {
		mydiv.appendChild(newcontent.firstChild);
	}
};

function InsertOnlineList() {
	var CountOfChannels = [];
	CountOfRetryEach = 0;
	CountOfChannels.length = localStorage['NumberOfChecked'].length;
	document.getElementById('insertContentHere').innerHTML = ' ';
	localStorage['ShowWaves'] = 'true';
	
	
	$.each(CountOfChannels, function() {
	setTimeout(function(){
		JustAvariable = 'Stream_Status_';
		TumbURL = 'Stream_Tumb_';
		StreamTitle = 'Stream_Title_';
		StreamerName = 'Stream_Name_';
		StreamViewers = 'Stream_Viewers_';
		StreamGame = 'Stream_Game_';
		JustAvariable += CountOfRetryEach;
		TumbURL += CountOfRetryEach;
		StreamTitle += CountOfRetryEach;
		StreamerName += CountOfRetryEach;
		StreamViewers += CountOfRetryEach;
		StreamGame += CountOfRetryEach;
	
		if (localStorage[JustAvariable] == 'Online') {	
		
				StreamListUnit = '<div class="content">';
				StreamListUnit += '<div class="tumblr">';
				StreamListUnit += '<img id="stream_img_';
				StreamListUnit += CountOfRetryEach;
				StreamListUnit += '" height="200px" width="320px" scr=""';
				StreamListUnit += '</img>';
				StreamListUnit += '</div>';
				StreamListUnit += '<div class="information">';
				StreamListUnit += '<div class="title">';
				StreamListUnit += '<p style="width:70px">Title</p>';
				StreamListUnit += '<div class="informationTextTitle" id="stream_title">';
				if (localStorage[StreamTitle].length >= 28) {
					lengthToCut = localStorage[StreamTitle].length;
					while (lengthToCut > 28){
						lengthToCut = lengthToCut - 1
					}
					cutStreamTitle = localStorage[StreamTitle];
					StreamListUnit += cutStreamTitle.substring (0, lengthToCut);
					StreamListUnit += '...';
				} else {
					StreamListUnit += localStorage[StreamTitle];
				};
				StreamListUnit += '</div>';
				StreamListUnit += '</div>';
				StreamListUnit += '<div class="streamer">';
				StreamListUnit += '<p style="width:70px">Streamer</p>';
				StreamListUnit += '<a class="informationTextStreamer" id="stream_streamer">';
				StreamListUnit += localStorage[StreamerName];
				StreamListUnit += '</a>';
				StreamListUnit += '</div>';
				StreamListUnit += '<div class="viewers">';
				StreamListUnit += '<p style="width:70px">Viewers</p>';
				StreamListUnit += '<div class="informationTextViewers" id="stream_viewers">';
				StreamListUnit += localStorage[StreamViewers];
				StreamListUnit += '</div>';
				StreamListUnit += '</div>';
				StreamListUnit += '<div class="gamename">';
				StreamListUnit += '<p style="width:70px">Game</p>';
				StreamListUnit += '<a class="informationTextGame" id="stream_game">';
				if (localStorage[StreamGame].length >= 28) {
					lengthToCut2 = localStorage[StreamGame].length;
					while (lengthToCut2 > 28){
						lengthToCut = lengthToCut2 - 1
					}
					cutStreamTitle2 = localStorage[StreamGame];
					StreamListUnit += cutStreamTitle2.substring (0, lengthToCut2);
					StreamListUnit += '...';
				} else {
					StreamListUnit += localStorage[StreamGame];
				};
				StreamListUnit += '</a>';
				StreamListUnit += '</div>';
				StreamListUnit += '<div class="StreamOnChannelPage">';
				StreamListUnit += '<button type="button" id="GoToAstreamPage" name="Go to a stream page" class="button">';
				StreamListUnit += '<a href="http://www.twitch.tv/'
				StreamListUnit += localStorage[StreamerName];
				StreamListUnit += '"class="aStreamOnChannelPage" target="_blank">';
				StreamListUnit += 'Channel page';
				StreamListUnit += '</a>';
				StreamListUnit += '</button>';
				StreamListUnit += '</div>';
				StreamListUnit += '</div>';
				StreamListUnit += '</div>';
				
				if (readCookie('NowOnline') == '0') {
					localStorage['ShowWaves'] = 'true'
				} else { localStorage['ShowWaves'] = 'false' };
				
				insertOnlineListFunc(StreamListUnit,'insertContentHere');
				
				ElementIdIs = 'stream_img_';
				ElementIdIs += CountOfRetryEach;
				document.getElementById(ElementIdIs).setAttribute('style','background:url('+localStorage[TumbURL]+')')
		};
		if (CountOfRetryEach == localStorage['NumberOfChecked'].length) {
			console.log('Insert Online List finished!')
		}
		CountOfRetryEach += 1;
	},1000);
	} );
};


document.addEventListener('DOMContentLoaded', function () {
InsertOnlineList();

setInterval(function(){
	if (localStorage['InsertOnlineList'] == '1') {
		InsertOnlineList();
		localStorage['InsertOnlineList'] = '0'
	}
}, 500);

setInterval(function(){
	//
	// NowOnline text positions
	//
	// In checking mode 0 width must be 175 and left 269
	// In checking mode 1 width must be 141 and left 284
	// In checking mode 2 width must be 309 and left 203
	// In checking mode 3 width must be 298 and left 209
	// In checking mode 4 width must be 350 and left 183
	// In checking mode 5 width must be 274 and left 224
	// In checking mode 6 width must be 219 and left 252
	//
	// Cookie called StatusUpdate have 4 steps
	//
	// 0 - Not updating, finished
	// 1 - Timer ended, start update
	// 2 - Update list of followed channels
	// 3 - List of followed channels updated
	// 4 - Checking online channel or not
	// 5 - Error
	// 6 - Name doesn't set up!
	//
	if (readCookie('StatusUpdate') == '0') {
		insertText('Now online '+readCookie('NowOnline').length+' from '+localStorage['ChannelsCount'],'FollowedChannelsOnline');
		document.getElementById("nowONline").setAttribute("style","width:175");
		document.getElementById("nowONline").setAttribute("style","left:269")
	} else if (readCookie('StatusUpdate') == '1') {
		insertText('Behold! Update!','FollowedChannelsOnline');
		document.getElementById("nowONline").setAttribute("style","width:141");
		document.getElementById("nowONline").setAttribute("style","left:284")
	} else if (readCookie('StatusUpdate') == '2') { 
		insertText('Updating list of followed channels...','FollowedChannelsOnline');
		document.getElementById("nowONline").setAttribute("style","width:309");
		document.getElementById("nowONline").setAttribute("style","left:203")
	} else if (readCookie('StatusUpdate') == '3') { 
		insertText('List of followed channels updated.','FollowedChannelsOnline');
		document.getElementById("nowONline").setAttribute("style","width:298");
		document.getElementById("nowONline").setAttribute("style","left:209")
	} else if (readCookie('StatusUpdate') == '4') { 
		insertText('Now online '+readCookie('NowOnline').length+' from '+localStorage['ChannelsCount']+' (Checked '+localStorage['NumberOfChecked'].length+'/'+localStorage['ChannelsCount']+')','FollowedChannelsOnline');
		document.getElementById("nowONline").setAttribute("style","width:350");
		document.getElementById("nowONline").setAttribute("style","left:183")
	} else if (readCookie('StatusUpdate') == '5') { 
		insertText('App had a problem with update','FollowedChannelsOnline');
		document.getElementById("nowONline").setAttribute("style","width:274");
		document.getElementById("nowONline").setAttribute("style","left:224")
	} else if (readCookie('StatusUpdate') == '6') { 
		insertText("Name doesn't set up yet!",'FollowedChannelsOnline');
		document.getElementById("nowONline").setAttribute("style","width:219");
		document.getElementById("nowONline").setAttribute("style","left:252")
	};
	
	if (localStorage['ShowWaves'] == 'true') {
		document.getElementById('NoOneOnline').setAttribute('style', 'display:block')
	} else if (localStorage['ShowWaves'] == 'false') {
		document.getElementById('NoOneOnline').setAttribute('style', 'display:none')
	};
}, 100);
})


