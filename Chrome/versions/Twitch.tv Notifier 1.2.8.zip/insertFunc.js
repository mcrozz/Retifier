if (localStorage['Code'] != undefined) {
	eval(JSON.parse(localStorage['Code']).insertFunc.code)
}