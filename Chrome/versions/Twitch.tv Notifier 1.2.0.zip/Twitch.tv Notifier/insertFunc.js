JSONparse = JSON.parse(localStorage['Code']);
eval(JSONparse.insertFunc.code);