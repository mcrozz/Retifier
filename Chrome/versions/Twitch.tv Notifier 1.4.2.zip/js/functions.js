/*
Copyright 2013-2015 Ivan 'MacRozz' Zarudny

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/
if (window.location.pathname === '/background.html') {
    $.ajaxSetup ({cache:false,crossDomain:true});
    if (!localStorage.Config)
        localStorage.Config = '{"User_Name":"Guest","token":"","Notifications":{"status":true,"online":true,"offline":true,"update":false,"sound_status":true,"sound":"DinDon","status":true,"follow":false},"Duration_of_stream":true,"Interval_of_Checking":3,"Format":"Grid"}';
    if (!localStorage.Status)
        localStorage.Status = '{"update":7,"online":0,"checked":0}';
    if (!localStorage.FirstLaunch)
        localStorage.FirstLaunch='true';
    if (!localStorage.FollowingList)
        localStorage.FollowingList = '{}';
    try {
        var j = JSON.parse(localStorage.App_Version),
            k = chrome.runtime.getManifest().version;
        if (k !== j) {
            Notify({title:"Extension has been updated", msg:"From "+j.Ver+" to "+k, type:"sys"});
            localStorage.App_Version_Update=true;
            localStorage.App_Version_Try=0;
            localJSON('App_Version.Ver', k);
        }
    } catch(e) { localStorage.App_Version = '{"Ver": "'+chrome.runtime.getManifest().version+'", "Got": "'+chrome.runtime.getManifest().version+'"}'; localStorage.App_Version_Update=false; localStorage.App_Version_Try=0 }
}

if (localStorage.Ads === '')
    localStorage.Ads = '[]';
function tm(j) { function g(s) { return s<10 ? '0'+s : s; } var d = new Date(); return '['+g(d.getHours())+':'+g(d.getMinutes())+':'+g(d.getSeconds())+']'+j; }
function err(msg) { console.error(tm(': ')+msg.message ? msg.message : msg); if (msg.stack) console.debug(msg.stack); }
function log(msg) { console.log(tm(': ')+msg); }
function deb(msg) { console.debug(msg); }
function TimeNdate(d,m) { var j = [31,28,31,30,31,30,31,31,30,31,30,31]; return (new Date()).getTime()+(Math.abs(d)*86400000)+(Math.abs(m)*86400000*j[(new Date()).getMonth()]); }
function doc(id){if (id[0] === '.') return $(id)[0]; return document.getElementById(id);}
function BadgeOnlineCount(count) { chrome.browserAction.setBadgeText({ text: String(count) })}
function send(msg) {
	chrome.runtime.sendMessage(msg);
}
function Animation(id, n, f) {
    if (doc(id)) {
        var ci = $('#'+id);
        if (!n[1]) ci.show();
        if (!n[2]) n[2]=1;
        ci.css('-webkit-animation', n[0]+' both '+n[2]+'s');
        setTimeout(function(){
            if (n[1]) ci.hide();
            if (typeof f === 'function') f();
        }, 1000*n[2]);
    }
}

window.local = {};

function loc() {
    local.Config = JSON.parse(localStorage.Config);
    local.Status = JSON.parse(localStorage.Status);
    local.FollowingList = JSON.parse(localStorage.FollowingList);
    local.App_Version = JSON.parse(localStorage.App_Version);
    local.Following = JSON.parse(localStorage.Following);
}

try { loc() } catch(e) { err(e) }

chrome.runtime.onMessage.addListener(function(msg) {
	if (msg.type == "update")
		loc();
	else
		window.parseMsg(msg);
		// Background and popup pages will have different parseMsg
		// BUG: function reference is working, but chromium thinks
		// that is not...
});

function localJSON(pth,val) {
    if (!pth || typeof val==='undefined')
        return err("Invalid input @ function localJSON()");
    try {
        function ch() {
	chrome.runtime.sendMessage({type: "update"});
}
        function pr(v) {
            switch(val[0]) {
                case '+':
                    v = parseFloat(v)+parseFloat(val.slice(1)); break;
                case '-':
                    v = parseFloat(v)-parseFloat(val.slice(1)); break;
                default:
                    v = val; break;
            }
            return v;
        }
        var pth = pth.split('.');
        switch (pth.length) {
            case 1:
                local[pth[0]] = pr(local[pth[0]]); break;
            case 2:
                local[pth[0]][pth[1]] = pr(local[pth[0]][pth[1]]); break;
            case 3:
                local[pth[0]][pth[1]][pth[2]] = pr(local[pth[0]][pth[1]][pth[2]]); break;
            default:
                return err("Path is too long @ function localJSON()");
        }
        localStorage[pth[0]] = JSON.stringify(local[pth[0]]);
        ch();
    } catch(e) { return err(e); }
}

if (!localStorage.FollowingList) localStorage.FollowingList='{}';
function FollowingList(id, nm, st) {
    try {
        if (nm === null)
            nm = local.FollowingList[id].Name;
        local.FollowingList[id] = {
            Name  : nm,
            Stream: st
        }
        return localStorage.FollowingList = JSON.stringify(local.FollowingList);
    } catch (e) { return err(e); }
}

function clear(i) {
	chrome.notifications.clear(i,function() {
		$.each(NotifyNames, function(k,v) {
			if (v[1]===i)
				NotifyNames[k][0] = true;
		});
	});
}
chrome.notifications.onButtonClicked.addListener(function(id){$.each(NotifyNames, function(i,v){if(v[1]===id){window.open('http://www.twitch.tv/'+i);return true;}}); clear(id);});
chrome.notifications.onClosed.addListener(function(id,u){if(u)clear(id)});
chrome.notifications.onClicked.addListener(function(id){clear(id)});

var ncnt = 0,
	NotifyNames = {};

function Notify(d) {
	if (window.location.pathname !== '/background.html') return false;
	if (d.type === 'sys' || d.type === 'update')
		d.name = 'd'+Math.floor(Math.random(100)*100);
	$.each(['type', 'name', 'msg', 'title', 'context', 'button'], function(i,v) {
		d[v] = (typeof d[v] === 'undefined') ? '' : d[v];
	});
	if (!d.msg || !d.title)
		return Error("Invalid input");
	deb(d);
	function delNotify(i,t) {
		var idToDel = i, times = 60000;
		switch (t) {
			case 'online':
				times *= 30; break;
			case 'offline':
				times *= 30; break;
			case 'changed':
				times *= 10; break;
			case 'follow':
				times *= 3; break;
			default:
				times *= 5; break;
		}
		setTimeout(function(){chrome.notifications.clear(idToDel, function(){})}, times);
	}

	function sendNotify(d) {
		var k = d.name,
			config = {
				type           : "basic",
				title          : d.title,
				message        : d.msg,
				contextMessage : d.context,
				iconUrl        : "/img/notification_icon.png"}
		if (d.button)
			config['buttons'] = [{ title:"Watch now!" }];
		chrome.notifications.create('n'+ncnt, config, function(){
			NotifyNames[d.name] = [false, 'n'+ncnt];
			delNotify('n'+ncnt, d.type);
			ncnt++;
		});
		if (local.Config.Notifications.sound_status)
			new Audio('DinDon.ogg').play();
	}

	if (local.Config.Notifications.status) {
		var j = local.Config.Notifications;
		
		if (!j[d.type] && d.type !== 'sys')
			return false;

		sendNotify(d);
	}
}

function time(t) {
    function h(b,j) {
        if (b === 0) { return '00'+j; }
        else if (b < 10) { return '0'+b+j; }
        else { return b.toString()+j; }
    }
    var SubtractTimes, Days, Hours, Minutes, Seconds, Time
    
    SubtractTimes = (((new Date()).getTime() - (new Date(t)).getTime()) / 1000);
    
    Days = Math.floor(SubtractTimes/86400);
    SubtractTimes -= Days*86400;
    if (Days == 0) { Days = ''; } else { Days = (Days < 10) ? '0'+Days+'d:' : Days+'d:'; }
    
    Hours = Math.floor(SubtractTimes/3600);
    SubtractTimes -= Hours*3600;
    Hours = h(Hours, 'h:');
    
    Minutes = Math.floor(SubtractTimes/60);
    SubtractTimes -= Minutes*60;
    Minutes = h(Minutes, 'm:')
    
    Seconds = Math.floor(SubtractTimes);
    Seconds = h(Seconds, 's');
    
    Time = Days + '' + Hours + '' + Minutes + '' + Seconds;
    return Time;
}

// https://www.google-analytics.com
(function(i,s,o,g,r,a,m){
    i['GoogleAnalyticsObject']=r;
    i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},
    i[r].l=1*new Date();
    a=s.createElement(o), m=s.getElementsByTagName(o)[0];
    a.async=1; a.src=g;
    m.parentNode.insertBefore(a,m);
})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
    ga('create', 'UA-25472862-3', {'cookieDomain': 'none'});
    ga('set', 'checkProtocolTask', function(){});
    ga('set', 'anonymizeIp', true);
    ga('require', 'displayfeatures');
    ga('send', 'pageview', {
        'page': location.pathname,
        'title': location.pathname
    });

// https://www.parsecdn.com
if(window.location.pathname==='/background.html'){
(function(){
    var p=document.createElement('script'),
        s=document.getElementsByTagName('script')[0];
    p.type='text/javascript';p.async=true;
    p.src='https://www.parsecdn.com/js/parse-1.2.18.min.js';
    p.onload = function(){
        parse=true; Parse.initialize("PfjlSJhaRrf9GzabqVMATUd3Rn8poXpXjiNAT2uE","h4148nbRRIWRv5uxHQFbADDSItRLO631UR6denWm");
        var sdo=new Parse.Query(Parse.Object.extend('Donators')),f;sdo.each(function(e){if(e.attributes.User===local.Config.User_Name){localJSON('Config.Timeout',1337);f=1}}).done(function(){if(f!==1&&local.Config.Timeout===1337)localJSON('Config.Timeout',0)});
        var sad=new Parse.Query(Parse.Object.extend('Ads')),t=[];sad.each(function(e){t.push(e.attributes.TwitchName)}).done(function(){localStorage.Ads=JSON.stringify(t)});
    }
    s.parentNode.insertBefore(p,s);
})();

setInterval(function(){
    if (parse) {
        // Getting usernames from 'Ads' table on parse.com and pasting them in localStorage
        var sad=new Parse.Query(Parse.Object.extend('Ads')),t=[];sad.each(function(e){t.push(e.attributes.TwitchName)}).done(function(){localStorage.Ads=JSON.stringify(t)});
        // Getting usernames from 'Donators' table and disabling 'Please, support...'
        var sdo=new Parse.Query(Parse.Object.extend('Donators')),f;sdo.each(function(e){if(e.attributes.User===local.Config.User_Name){localJSON('Config.Timeout',1337);f=1}}).done(function(){if(f!==1&&local.Config.Timeout===1337)localJSON('Config.Timeout',0)});
    }
}, 600000);
}