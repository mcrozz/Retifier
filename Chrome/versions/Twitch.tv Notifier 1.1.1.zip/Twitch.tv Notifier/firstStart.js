function firstLaunchUser() {
	createCookie('UserName',document.getElementById('SetUpUserNameInp').value,365)
};

setInterval(function(){
if (localStorage['FirstLaunch'] == 'true'){
	createCookie('StatusUpdate','7',365);
	localStorage['ShowWaves'] = 'false';
	
	document.getElementById('NoOneOnline').setAttribute('style', 'display:none');
	document.getElementById('FollowedChannelsOnline').innerHTML = "Greetings!";
	
	WelcomeMsg = '<div class="Welcome">';
	WelcomeMsg += '<p class="pWelcome1">Hello!</p>';
	WelcomeMsg += '<p class="pWelcome2">Before you will use this app,</p>';
	WelcomeMsg += '<p class="pWelcome3">could you say your Twitch.tv name?</p>';
	WelcomeMsg += '<input type="text" name="userName" id="SetUpUserNameInp" value="" class="inSetUpUserName">';
	WelcomeMsg += '<p class="pWelcome4">Thanks for downloading this app!</p>';
	WelcomeMsg += '<p class="pWelcome5">Hope this app will be useful for you</p>';
	WelcomeMsg += '<button type="button" id="SetUpUserName" name="SetUpUserName" class="WelcomOK">OK</button>';
	WelcomeMsg += '</div>';
	
	if (document.getElementById('insertContentHere').innerHTML != WelcomeMsg) {
		document.getElementById('insertContentHere').innerHTML = WelcomeMsg;
		document.getElementById("SetUpUserName").addEventListener("click", firstLaunchUser);
	};
	
	if (document.getElementById('SetUpUserNameInp').value == readCookie('UserName')) {
		localStorage['FirstLaunch'] = 'false';
		document.getElementById('insertContentHere').innerHTML = null;
		createCookie('InstatntCheck','1',365);
		document.getElementById('NoOneOnline').setAttribute('style', 'display:block');
		setTimeout(function(){location.reload()},1000 * 10);
		document.getElementById('FollowedChannelsOnline').innerHTML = "Please wait a moment";
	}
}
}, 100);