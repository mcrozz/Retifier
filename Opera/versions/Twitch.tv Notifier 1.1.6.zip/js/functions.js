/*
Copyright 2013-2015 Ivan 'MacRozz' Zarudny

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/
function tm(j) { function g(s) { return s<10 ? '0'+s : s; } var d = new Date(); return '['+g(d.getHours())+':'+g(d.getMinutes())+':'+g(d.getSeconds())+']'+j; }
function err(msg) { console.error(tm(': ')+msg.message ? msg.message : msg); if (msg.stack) console.debug(msg.stack); }
function log(msg) { console.log(tm(': ')+msg); }
function deb(msg) { if(!msg)return; console.debug(msg); }
function TimeNdate(d,m) { var j = [31,28,31,30,31,30,31,31,30,31,30,31]; return (new Date()).getTime()+(Math.abs(d)*86400000)+(Math.abs(m)*86400000*j[(new Date()).getMonth()]); }
function _$(id){
    if ($.inArray(id[0], ['.', '#']) != -1) return $(id)[0];
    return $('#'+id)[0];
}
function BadgeOnlineCount(count) { chrome.browserAction.setBadgeText({ text: String(count) })}
function send(msg, callback) {
	if (typeof callback === 'function')
		chrome.runtime.sendMessage(msg, null, callback);
	else
		chrome.runtime.sendMessage(msg);
}

jQuery.fn.extend({
  anim: function(name, dur, hide) {
    var _this = this;

    if (this.css('display') === 'none' || !this.css('display'))
      this.show();

    this.css('-webkit-animation', name+' both '+dur+'s');
    setTimeout(function() {
      if (hide)
        _this.hide();
    }, dur);
  }
});

window.local = {
  tried: 0,
  init: function(w) {
    if (typeof w !== 'undefined') {
      if (typeof this[w] !== 'undefined' && w !== -1) {
        try {
          this[w] = JSON.parse(localStorage[w]);
        } catch(e) { return err(e); }
        return true;
      }
    }
    this.tried++;
    try {
      this.Config = JSON.parse(localStorage.Config);
      this.Status = JSON.parse(localStorage.Status);
      this.FollowingList = JSON.parse(localStorage.FollowingList);
      this.Following = JSON.parse(localStorage.Following);
      this.Games = JSON.parse(localStorage.Games);
      this.following.hash();
      this.tried = 0;
    } catch(e) {
      err(e);
      if (tried < 25)
        local.init();
    }
    return true;
  },
  set: function(pth, val) {
    if (!pth || typeof val==='undefined')
      return err("Invalid input @ function local.set()");
    try {
      function pr(v) {
        switch(val[0]) {
          case '+':
            return parseFloat(v)+parseFloat(val.slice(1));
          case '-':
            return parseFloat(v)-parseFloat(val.slice(1));
          default:
            return val;
        }
      }
      var pth = pth.split('.');
      switch (pth.length) {
        case 1:
          this[pth[0]] = pr(this[pth[0]]); break;
        case 2:
          this[pth[0]][pth[1]] = pr(this[pth[0]][pth[1]]); break;
        case 3:
          this[pth[0]][pth[1]][pth[2]] = pr(this[pth[0]][pth[1]][pth[2]]); break;
        default:
          return err("Path is too long @ function localJSON()");
      }
      localStorage[pth[0]] = JSON.stringify(this[pth[0]]);
      send({type:'update', data:pth[0]});
    } catch(e) { return err(e); }
  },
  default: {
    Name: 'invalid',
    Stream: false,
    Notify: true,
    d_name: 'invalid'
  },
  following: {
    get: function(n) {
      // Returns streamer obj
      if (isNaN(n))
        return local.FollowingList[local.following.map[n]];
      else
        return local.FollowingList[n];
    },
    set: function(id, dt) {
      try {
        if (isNaN(id))
          id = local.following.map[id];

        var tm = local.FollowingList[id];
        if (typeof tm !== 'undefined')
          $.each(['Name', 'Stream', 'Notify', 'd_name'], function(i,v) {
            if (typeof tm[v] === 'undefined')
              dt[v] = local.default[v];
            else if (typeof dt[v] === 'undefined')
              dt[v] = tm[v];
            });

        local.FollowingList[id] = dt;
        localStorage.FollowingList = JSON.stringify(local.FollowingList);
        send({type: 'update', data: 'FollowingList'});
        return true;
      } catch (e) { return err(e); }
    },
    del: function(name) {
      var newObj = {};
      $.each(local.FollowingList, function(i,v) {
        if (v.Name !== name)
          newObj[i] = v;
      });
      try {
        localStorage.FollowingList = JSON.parse(newObj);
        local.init('FollowingList');
      } catch(e) {}
    },
    map: { /* String : Int ..*/ },
    hash: function() {
      // Hash names and theirs id
      local.following.map = {};
      $.each(local.FollowingList, function(i,v) {
        local.following.map[v.Name] = i;
      });
    }
  },
  game: function(name) {
    setTimeout(function() {
      if (local.Games.length > 50) {
        localStorage.Games = '{}';
        local.init('Games');
      }
      var dname = encodeURI(name);
      $.getJSON('https://api.twitch.tv/kraken/search/games?q='+dname+'&type=suggest')
      .done(function(e) {
        var isThere = false;
        if (e.games.length === 0)
          isThere = false;
        else
          $.each(e.games, function(i,v) {
            if (v.name === name) {
              isThere = true;
            }
          });
        // preventing from error on local.set side
        dname = dname.replace(/./g, '');
        local.set('Games.'+dname, isThere);
      });
    }, 0);
  }
};

(function() {
  if (window.location.pathname === '/background.html') {
    $.ajaxSetup ({cache:false,crossDomain:true});
    if (!localStorage.Config)
      localStorage.Config = '{"User_Name":"Guest","token":"","Notifications":{"status":true,"online":true,"offline":true,"update":false,"sound_status":true,"sound":"DinDon","status":true,"follow":false},"Duration_of_stream":true,"Interval_of_Checking":3,"Format":"Grid","Screen":0.34}';
    if (!localStorage.Status)
      localStorage.Status = '{"update":7,"online":0,"checked":0}';
    if (!localStorage.FirstLaunch)
      localStorage.FirstLaunch='true';
    if (!localStorage.FollowingList)
      localStorage.FollowingList = '{}';
    if (localStorage.Ads === '')
      localStorage.Ads = '[]';
    if (!localStorage.FollowingList)
      localStorage.FollowingList='{}';
    if (!localStorage.Games)
      localStorage.Games = '{}';
    if (!localStorage.Following)
      localStorage.Following = 0;

    local.init();

    if (!local.Config.Format)
      local.set('Config.Format', 'Grid');

    if (local.Config.Format == 'Mini')
      local.set('Config.Format', 'Light');

    if (!local.Config.Screen)
        local.set('Config.Screen', 0.34);


    var j = localStorage.App_Version,
        k = chrome.runtime.getManifest().version;

    // Fallback for old versions
    try{
      if (j[0] === '{') {
        var te = JSON.parse(j);
        localStorage.App_Version = te.Ver;
        j = te.Ver;
      }
    } catch(e) {}

    if (!j) {
      localStorage.App_Version = k;
      j = k;
    }

    if (k != j) {
      chrome.notifications.create("new_update", {
        type   : "basic",
        title  : "Extension has been updated",
        message: "From "+j+" to "+k,
        iconUrl: "/img/notification_icon.png"
      }, function() {});

      localStorage.App_Version = k;
      window.toShow = 123;
    }
  } else
    local.init();
})();


/*
* msg : object {
*  type : String [ update,  ],
*  data : String or object
* }
*/
chrome.runtime.onMessage.addListener(function(msg, s, resp) {
	if (typeof msg === 'string')
		msg = {type: msg};

	if (window.location.pathname === '/background.html') {
		// If something is wrong or new update
		// This object will be indicate what's
		// went wrong:
		// * 777 - token is invalid
		// * 123 - extension updated
		if (!window.toShow)
			window.toShow = -1;

		switch(msg.type) {
			case "refresh": bck.init(); break;
			case "getOnline": bck.getList(); break;
			case "flush": bck.flush(); break;
			case "update": local.init(msg.data); break;
			case "getInf": resp({type:"inf", data:toShow}); toShow=-1; break;
			case "reload": chrome.runtime.reload(); break;
		}
	} else {
		switch(msg.type) {
			case "update": local.init(msg.data); break;
			case "following": insert(msg.data); break;
		}
		if (msg.type === 'update' && msg.data === 'Status')
			updateStatus();
	}
});


function clear(i) {
	chrome.notifications.clear(i, function() {
		var j = {};
		$.each(StrNames, function(k,v) {
			if (k!==i)
				j[k] = v;
		});
		StrNames = j;
	});
}
/*chrome.notifications.onButtonClicked.addListener(function(id){
	// If user clicked button 'Install' in notification
	if (id === 'new_update')
		return chrome.runtime.reload();

	// Clicked 'Watch now'
	window.open('http://www.twitch.tv/'+StrNames[id]);
	clear(id);
	return true;
});*/
chrome.notifications.onClosed.addListener(function(id,u){
	if(u)
		clear(id);
});
chrome.notifications.onClicked.addListener(function(id) {
	clear(id);
});
chrome.runtime.onUpdateAvailable.addListener(function(m) {
	// Update available, informate user
	notify.send({
		type: 'sys',
		msg: 'Install update right now?',
		title: 'New update available!',
		button: 'Reload extension',
		name: 'update'
	});
});

var ncnt = 0;
var StrNames = {};

if (!localStorage.timeOut)
	localStorage.timeOut = '{}';
var timeOut = {
	init: function() {
		try {
			this.names = JSON.parse(localStorage.timeOut);
			timeOut.check();
		} catch(e) { return err(e); }
	},
	set: function(name) {
		this.names[name] = (new Date()).toJSON();
		this.save();
	},
	save: function() {
		try {
			localStorage.timeOut = JSON.stringify(this.names);
		} catch(e) {return err(e); }
	},
	find: function(n) {
		// return true if more than 15 second
		if (typeof this.names[n] === 'undefined')
			return true;

		var dif = ((new Date())-(new Date(this.names[n])))/1000;
		return dif>=15;
	},
	chck: -1,
	check: function() {
		if (this.chck !== -1)
			return true;

		this.chck = setTimeout(function() {
			var n = {}, ad = 0;
			for (var i in timeOut.names) {
				var c = timeOut.names[i];
				var dif = ((new Date())-(new Date(c)))/1000;
				if (dif<15) {
					n[i] = c;
					ad++;
				}
			}
			timeOut.names = ad===0 ? {} : n;
			timeOut.save();
			timeOut.chck = -1;
		}, 0);
	}
};
timeOut.init();

/*
* Input: d {
*  type: system, update, change etc
*  name: name for storage
*  msg
*  title
*  context
*  button: Boolean or String
* }
*/
window.notify = {
	send: function(d) {
		this.list.push(d);
		setTimeout(function() {
			var d = notify.last();
			if (window.location.pathname !== '/background.html')
				return false;

			if (d.type === 'sys' || d.type === 'update')
				if (!d.name) {
					d.name = 'd'+Math.floor(Math.random(100)*100);
				}

			$.each(['type', 'name', 'context', 'button'], function(i,v) {
				d[v] = (typeof d[v] === 'undefined') ? '' : d[v];
			});

			if (!d.msg || !d.title)
				return Error("Invalid input");

			deb(d);
			function delNotify(i,t) {
				var idToDel = i, times = 60000;
				switch (t) {
					case 'online':
						times *= 30; break;
					case 'offline':
						times *= 30; break;
					case 'changed':
						times *= 10; break;
					case 'follow':
						times *= 3; break;
					default:
						times *= 5; break;
				}
				setTimeout(function(){
					chrome.notifications.clear(idToDel, function(){});}, times);
			}

			function sendNotify(d) {
				var k = d.name,
					config = {
						type           : "basic",
						title          : d.title,
						message        : d.msg,
						contextMessage : d.context,
						iconUrl        : "/img/notification_icon.png"
					};

				/*if (typeof d.button === 'boolean' && d.button)
					config.buttons = [{ title:"Watch now!" }];
				else if (typeof d.button === 'string')
					config.buttons = [{ title:d.button }];*/

				chrome.notifications.create('n'+ncnt, config, function(){
					StrNames['n'+ncnt] = d.name;
					if (d.type != 'sys')
						timeOut.set(d.name);
					delNotify('n'+ncnt, d.type);
					ncnt++;
					if (local.Config.Notifications.sound_status)
						new Audio('DinDon.ogg').play();
				});
			}

			if (local.Config.Notifications.status) {
				// If system update
				if (d.type === 'sys')
					return sendNotify(d);

				// If user in timoue
				if (!timeOut.find(d.name))
					return false;

				var j = local.Config.Notifications;

				// If notification disabled
				if (!j[d.type])
					return false;

				sendNotify(d);
			}
		}, Math.floor(Math.random()*1000));
	},
	list: [/* notify queue goes here */],
	last: function() {
		var t = this.list[0];
		this.list.shift();
		return t;
	}
};


function time(t) {
  function h(b,j) {
      if (b === 0) { return '00'+j; }
      else if (b < 10) { return '0'+b+j; }
      else { return b.toString()+j; }
  }
  var SubtractTimes, Days, Hours, Minutes, Seconds, Time

  if (isNaN((new Date(t)).getTime())) return '';
  SubtractTimes = (((new Date()).getTime() - (new Date(t)).getTime()) / 1000);

  Days = Math.floor(SubtractTimes/86400);
  SubtractTimes -= Days*86400;
  if (Days == 0) { Days = ''; } else { Days = (Days < 10) ? '0'+Days+'d:' : Days+'d:'; }

  Hours = Math.floor(SubtractTimes/3600);
  SubtractTimes -= Hours*3600;
  Hours = h(Hours, 'h:');

  Minutes = Math.floor(SubtractTimes/60);
  SubtractTimes -= Minutes*60;
  Minutes = h(Minutes, 'm:')

  Seconds = Math.floor(SubtractTimes);
  Seconds = h(Seconds, 's');

  Time = Days + '' + Hours + '' + Minutes + '' + Seconds;
  return Time;
}

// https://www.google-analytics.com
(function(i,s,o,g,r,a,m){
  i['GoogleAnalyticsObject']=r;
  i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},
  i[r].l=1*new Date();
  a=s.createElement(o), m=s.getElementsByTagName(o)[0];
  a.async=1; a.src=g;
  m.parentNode.insertBefore(a,m);
})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-25472862-3', {cookieDomain: 'none'});
  ga('set', 'checkProtocolTask', function(){});
  ga('set', 'anonymizeIp', true);
  ga('require', 'displayfeatures');
  ga('send', 'pageview', {
    'page': location.pathname,
    'title': location.pathname
  });

// https://www.parsecdn.com
if(window.location.pathname==='/background.html'){
(function(){
  var p=document.createElement('script'),
    s=document.getElementsByTagName('script')[0];
  p.async=1; p.src='./js/parse-1.3.5.min.js';
  p.onload = function(){
    parse=true; Parse.initialize("PfjlSJhaRrf9GzabqVMATUd3Rn8poXpXjiNAT2uE","h4148nbRRIWRv5uxHQFbADDSItRLO631UR6denWm");
    var sdo=new Parse.Query(Parse.Object.extend('Donators')),f;sdo.each(function(e){if(e.attributes.User===local.Config.User_Name){local.set('Config.Timeout',1337);f=1}}).done(function(){if(f!==1&&local.Config.Timeout===1337)local.set('Config.Timeout',0)});
    var sad=new Parse.Query(Parse.Object.extend('Ads')),t=[];sad.each(function(e){t.push(e.attributes.TwitchName)}).done(function(){localStorage.Ads=JSON.stringify(t)});
  }
  s.parentNode.insertBefore(p,s);
})();

setInterval(function(){
  if (parse) {
    // Getting usernames from table 'Ads' on parse.com and inserting 'em in the localStorage
    var sad=new Parse.Query(Parse.Object.extend('Ads')),t=[];sad.each(function(e){t.push(e.attributes.TwitchName)}).done(function(){localStorage.Ads=JSON.stringify(t)});
    // Getting usernames from table 'Donators'
    var sdo=new Parse.Query(Parse.Object.extend('Donators')),f;sdo.each(function(e){if(e.attributes.User===local.Config.User_Name){local.set('Config.Timeout',1337);f=1}}).done(function(){if(f!==1&&local.Config.Timeout===1337)local.set('Config.Timeout',0)});
  }
}, 600000);
}
